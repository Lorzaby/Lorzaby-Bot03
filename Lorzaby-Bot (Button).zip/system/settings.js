let fs = require('fs') 
let chalk = require('chalk')
let moment = require('moment-timezone')

// Owner
global.owner = [
  ['6285381310740'],
  ['6285381310740'],
  ['6285381310740', 'Lorzaby', 'lorzaby.id@gmail.com', true]
] // Put your number here
global.mods = ['6285381310740'] // Moderator
global.prems = ['6285381310740'] // Premium
global.rose = '-';
global.xyro = 'ClaraKeyOfficial';
global.btc = 'UssanoziLorzabyKey';
global.xzn = 'Lorzaby';
global.lolkey = 'elainaAi';
global.yanz = 'UssanoziLorzabyKey';
global.alya = 'AxellDev';
global.zein = 'zenzkey_c22460242f6e',
global.APIs = {
    // API Prefix
    // name: 'https://website'
    xteam: 'https://api.xteam.xyz',
    lol: 'https://api.lolhuman.xyz',
    males: 'https://malesin.xyz',
    neoxr: 'https://api.neoxr.eu',
    xyro: 'https://api.xyroinee.xyz',
    btc: 'https://api.betabotz.eu.org',
    yanz: 'https://api.yanzbotz.live',
    xfarr: 'https://api.xfarr.com',
    alya: 'https://api.alyachan.dev',
    dzx: 'https://api.dhamzxploit.my.id',
    zein: 'https://api.zahwazein.xyz',
    rose: 'https://api.itsrose.rest',
    popcat: 'https://api.popcat.xyz',
    xzn: 'https://skizo.tech',
    saipul: 'https://saipulanuar.cf',
}
global.APIKeys = {
    // APIKey Here
    // 'https://website': 'apikey'
    'https://api.zahwazein.xyz': 'zenzkey_c22460242f6e',
    'https://api.xteam.xyz': 'cristian9407',
    'https://api.xyroinee.xyz': 'ClaraKeyOfficial',
    'https://api.neoxr.eu': 'Composing',
    'https://api.yanzbotz.live': 'UssanoziLorzabyKey',
    'https://api.xfarr.com': 'Kemii',
    'https://api.zahwazein.xyz': 'Kemii',
    'https://api.betabotz.eu.org': 'UssanoziLorzabyKey',
    'https://api.lolhuman.xyz': 'elainaAi',
    'https://api.itsrose.rest': '-',
    'https://skizo.tech': 'Lorzaby',
}

global.set = {
  bot: 'Lorzaby WhatsApp Bot',
  wm: `Lorzaby WhatsApp Bot`,
  footer: 'Lorzaby WhatsApp Bot',
  version: `9.9.9`,
  packname: 'WhatsApp Bot Lorzaby',
  author: 'Ussanozi Lorzaby'
}

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0

const spack = fs.readFileSync("lib/exif.json")
const stickerpack = JSON.parse(spack)
if (stickerpack.spackname == '') {
  var sticker_name = 'WhatsApp Bot'
  var sticker_author = 'Lorzaby'
} else {
  var sticker_name = 'WhatsApp Bot'
  var sticker_author = 'Lorzaby'
}

const file_exif = "lib/exif.json"
fs.watchFile(file_exif, () => {
  fs.unwatchFile(file_exif)
  console.log(chalk.redBright("Update 'exif.json'"))
  delete require.cache[file_exif]
  require('./lib/exif.json')
})

// Document
global.minety = pickRandom(['application/msword', 'application/vnd.ms-excel', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
global.kiku = 'application/vnd.android.package-archive'

// Database
global.version = '9.9.9'
global.sessionName = 'lorzaby'
global.gcbot = 'https://chat.whatsapp.com/Jyatvh2vxKlEIEkHS7KVxX'
global.sosmed = 'https://bento.me/lorzaby'
global.namebot = 'Lorzaby WhatsApp Bot'
global.thumb = 'https://telegra.ph/file/32e3b521faee1d02251b6.jpg'
global.thumbnail = 'https://telegra.ph/file/32e3b521faee1d02251b6.jpg'

global.qris = '-'
global.email = 'lorzaby.id@gmail.com'
global.creator = "6285381310740@s.whatsapp.net"
global.nomorbot = '628881362557'
global.nomorown = '6285381310740'

// Harga Nokos
global.nokosindo = '7000'
global.nokosusa = '8000'
global.nokosmalay = '12000'

// Panel
global.domain = '-' // Domain Web
global.apikey = '-' // Key PTLA
global.c_apikey = '-' // Key PTLC
global.eggs = '15'
global.locs = '1'

// Atlantic Pedia Api
global.atlaapi = 'jiKgbG6XBgU3E0zL0UjeXdELK5ExfzDycILGo5JWQYwITQ0UAZCoNZFd1MAOC2OY1I5qBFRdSV4wHzTUZl19e6T7IZF5ciLHn1MK'

// Medan Pedia Api
global.medan = ''
global.medanid = ''

// Sosial Media
global.sig = 'https://chat.whatsapp.com/Jyatvh2vxKlEIEkHS7KVxX'
global.syt = 'https://chat.whatsapp.com/Jyatvh2vxKlEIEkHS7KVxX'
global.sgh = 'https://chat.whatsapp.com/Jyatvh2vxKlEIEkHS7KVxX'
global.sgc = 'https://chat.whatsapp.com/Jyatvh2vxKlEIEkHS7KVxX' // Link Group WA
global.swa = 'https://wa.me/6285381310740' // Link WA Owner
global.swb = 'https://bento.me/lorzaby' // Link Discord
global.snh = 'https://nhentai.net/g/365296/' // Link nhentai

// Pembayaran
global.pdana = 'Not Found'
global.povo = 'Not Found'
global.pgopay = 'Not Found'
global.pulsa = 'Not Found'
global.pulsa2 = 'Not Found'
global.psaweria = 'Not Found'
global.ptrakteer = 'Not Found'
global.psbuzz = 'Not Found'

// Fake Size
global.fsizedoc = '99999999999999' // default 10TB
global.fpagedoc = '999'

global.useMulti = true
global.autoread = true

// Watermark
global.packname = 'Lorzaby Bot'
global.author = 'Lorzaby'
global.wm = 'ʟᴏʀᴢᴀʙʏ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ'
global.wm2 = 'ʟᴏʀᴢᴀʙʏ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ'
global.titlebot = `${global.wm}`
global.danied = '🔒 Akses Ditolak!'
global.done = 'Successfully!'
global.packname = 'WhatsApp Bot'
global.author = 'Ussanozi Lorzaby'
global.nameown = 'Ussanozi Lorzaby'
global.wait = '📩 Loading...'

// Tampilan
global.htki =  '───「' // Hiasan kiri
global.htka = '」──' // Hiasan kanan
global.htjava = '❃' // Hiasan
global.sa = '╭─'
global.gx = '│✇'
global.gy = '│•'
global.gz = '│'
global.sb = '╰────࿐'
global.kki = '「'
global.kka = '」'

global.multiplier = 1000 // The higher, The harder levelup

global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      trash: '🗑',
      armor: '🥼',
      sword: '⚔️',
      wood: '🪵',
      rock: '🪨',
      string: '🕸️',
      horse: '🐎',
      cat: '🐈' ,
      dog: '🐕',
      fox: '🦊',
      petFood: '🍖',
      iron: '⛓️',
      gold: '👑',
      emerald: '💚'
    }
    let results = Object.keys(emot).map(v =>vv [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})//