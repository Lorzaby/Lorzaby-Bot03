let handler = async (m, {
    conn,
    text
}) => {
    if (!text) throw "Input your text"
    await conn.sendFile(m.chat, global.API("https://some-random-api.com", "/canvas/youtube-comment", {
        avatar: await conn.profilePictureUrl(m.sender, "image").catch(_ => "https://telegra.ph/file/24fa902ead26340f3df2c.png"),
        comment: text,
        username: m.name
    }), "error.png", "", m)
}
handler.help = ["ytc *<text>*"]
handler.tags = ["sticker"]
handler.command = /^(ytc)$/i
module.exports = handler