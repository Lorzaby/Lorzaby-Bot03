let handler = async (m, { conn, text }) => {
        if (!text) return conn.reply(m.chat, '*Example:* .setbiobot lorzaby', m)
		await conn.updateProfileStatus(text).catch(_ => _)
		conn.reply(m.chat, 'Successfully!', m)
}
handler.help = ['setbotbio *<text>*']
handler.tags = ['owner']
handler.command = /^setbiobot|setbotbio$/i
handler.owner = true

module.exports = handler