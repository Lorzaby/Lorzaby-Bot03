const axios = require("axios")
const cheerio = require("cheerio")
const btch = require("btch-downloader")
const { generateWAMessageFromContent, prepareWAMessageMedia,  proto, generateWAMessageContent  } = require("@whiskeysockets/baileys")

let handler = async (m, { conn, usedPrefix, command, args, text }) => {
	if (!args[0] ) return m.reply(`*Example:* ${usedPrefix+command} *<url>*`)
	if (!args[0].match(/tiktok/gi)) throw `Link yang anda berikan mungkin salah!`
	
	// Reaction emoji untuk indikator proses
	await conn.sendMessage(m.chat, { react: { text: "📩", key: m.key, }})

	try {
		let api = `https://dlpanda.com/id?url=${args[0]}&token=G7eRpMaa`
		let response = await axios.get(api)
		const html = response.data
		const $ = cheerio.load(html)
		let asd = []
		let img = []
		
		async function createImage(url) {
			const { imageMessage } = await generateWAMessageContent({
				image: {
					url
				}
			}, {
				upload: conn.waUploadToServer
			})
			return imageMessage;
		}
		
		$('div.col-md-12 > img').each((index, element) => {
			img.push($(element).attr('src'))
		})
		
		asd.push({ img })
		let fix = img.map((e, i) => {
			return e
		})
		
		if (fix.length === 0) {
			let url = await btch.ttdl(args[0])
			let vid = url.video
			await conn.sendFile(m.chat, vid, "tiktok.mp4", "*Title:* " + url.title, m)
			await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key, }})
		} else {
			let i = 1
			let push = []
			for (let lucuy of fix) {
			    push.push({
			      body: proto.Message.InteractiveMessage.Body.fromObject({
			        text: `Gambar ${i++}`
			      }),
			      footer: proto.Message.InteractiveMessage.Footer.fromObject({
			        text: global.botname
			      }),
			      header: proto.Message.InteractiveMessage.Header.fromObject({
			        title: '', 
			        hasMediaAttachment: true,
			        imageMessage: await createImage(lucuy)
			      }),
			      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
			        buttons: [
			          {
			            "name": "cta_url",
			            "buttonParamsJson": `{"display_text":"Owner","url":"https://wa.me/6285381310740","merchant_url":"https://wa.me/6285381310740"}`
			          }
			        ]
			      })
			    });
			}
			
			const bot = generateWAMessageFromContent(m.chat, {
			    viewOnceMessage: {
			      message: {
			        messageContextInfo: {
			          deviceListMetadata: {},
			          deviceListMetadataVersion: 2
			        },
			        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
			          body: proto.Message.InteractiveMessage.Body.create({
			            text: "*ᴜɴᴛᴜᴋ ᴍᴇɴʏɪᴍᴘᴀɴ ɢᴀᴍʙᴀʀ:* ᴋʟɪᴋ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ꜰᴏᴛᴏ, ᴋʟɪᴋ ᴛɪᴛɪᴋ ᴛɪɢᴀ ᴘᴏᴊᴏᴋ ᴋᴀɴᴀɴ ᴀᴛᴀꜱ, ᴋʟɪᴋ ꜱɪᴍᴘᴀɴ."
			          }),
			          footer: proto.Message.InteractiveMessage.Footer.create({
			            text: "ʟᴏʀᴢᴀʙʏ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ",
			          }),
			          header: proto.Message.InteractiveMessage.Header.create({
			            hasMediaAttachment: false
			          }),
			          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
			            cards: [
			              ...push
			            ]
			          })
			        })
			      }
			    }
			}, { quoted:m });
			
			await conn.relayMessage(m.chat, bot.message, {
			    messageId: bot.key.id
			});
		}
		// Reaction emoji selesai proses
		await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key, }})
	} catch(e) {
		console.log(e)
		await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key, }})
		throw `*Error:* ${e}`
	}
}

handler.help = ['tiktok2'].map(v => v + ' *<url>*')
handler.tags = ['downloader']
handler.command = /^(tiktok2|tt2)$/i
handler.register = true;
handler.limit = true;
module.exports = handler