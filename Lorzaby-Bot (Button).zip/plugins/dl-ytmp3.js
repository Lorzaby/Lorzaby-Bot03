const axios = require('axios');

const SaveTube = {
    headers: {
        'accept': '*/*',
        'referer': 'https://ytshorts.savetube.me/',
        'origin': 'https://ytshorts.savetube.me/',
        'user-agent': 'Postify/1.0.0',
        'Content-Type': 'application/json'
    },
    
    cdn() {
        return Math.floor(Math.random() * 11) + 51;
    },
    
    async fetchData(url, cdn, body = {}) {
        const headers = {
            ...this.headers,
            'authority': `cdn${cdn}.savetube.su`
        };

        try {
            const response = await axios.post(url, body, { headers });
            return response.data;
        } catch (error) {
            console.error(error);
            throw error;
        }
    },
    
    dLink(cdnUrl, videoKey) {
        return `https://${cdnUrl}/download`;
    },
    
    async dl(link) {
        const cdnNumber = this.cdn();
        const cdnUrl = `cdn${cdnNumber}.savetube.su`;
        
        const videoInfo = await this.fetchData(`https://${cdnUrl}/info`, cdnNumber, { url: link });
        const badi = {
            downloadType: 'audio',
            quality: '128',
            key: videoInfo.data.key
        };

        const dlRes = await this.fetchData(this.dLink(cdnUrl, videoInfo.data.key), cdnNumber, badi);

        return {
            link: dlRes.data.downloadUrl,
            duration: videoInfo.data.duration,
            durationLabel: videoInfo.data.durationLabel,
            thumbnail: videoInfo.data.thumbnail,
            title: videoInfo.data.title,
            titleSlug: videoInfo.data.titleSlug
        };
    }
};

async function handler(m, { conn, args, usedPrefix, command }) {
    if (!args[0]) throw `*Masukkan URL YouTube yang valid*\n\n*Contoh:*\n${usedPrefix + command} https://youtu.be/XXXXX`;
    
    try {
        m.reply('*📩 Sedang memproses audio...*');
        
        const result = await SaveTube.dl(args[0]);
        
        // Menyusun opsi pesan dengan format yang lebih menarik
        const messageOptions = {
            audio: { 
                url: result.link 
            },
            mimetype: 'audio/mpeg',
            ptt: false,
            fileName: `${result.title}.mp3`,
            thumbnail: { url: result.thumbnail },
            contextInfo: {
                externalAdReply: {
                    title: result.title,
                    body: 'YouTube Audio • 128kbps',
                    mediaUrl: args[0],
                    mediaType: 2,
                    thumbnailUrl: result.thumbnail,
                    sourceUrl: args[0]
                }
            }
        };
        
        // Kirim pesan audio dengan format baru
        await conn.sendMessage(m.chat, messageOptions, { quoted: m });
        
    } catch (error) {
        console.error(error);
        throw `*Terjadi kesalahan:* ${error.message}`;
    }
}

handler.help = ['ytmp3 <url>'];
handler.tags = ['downloader'];
handler.command = /^(ytmp3)$/i;
handler.limit = 5
handler.premium = false;

module.exports = handler;