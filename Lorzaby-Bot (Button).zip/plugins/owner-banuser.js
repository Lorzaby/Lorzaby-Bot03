let handler = async (m, { conn, text }) => {
    let user = global.db.data.users[m.sender]
    
    // Check if input format is correct
    if (!text) return conn.reply(m.chat, '*Example:* .ban 6285381310740 1h\nFormat: number duration(s/m/h/d)', m)
    
    // Split input into number and duration
    let [number, duration = ''] = text.split(' ')
    
    let who
    if (m.isGroup) {
        who = number.includes('@') ? number.split('@')[1] + '@s.whatsapp.net' : number + '@s.whatsapp.net'
    } else {
        who = number + '@s.whatsapp.net'
    }
    
    if (!who || !global.db.data.users[who]) return conn.reply(m.chat, 'User not found or invalid number', m)
    
    let targetUser = global.db.data.users[who]
    
    // Check if user is VIP
    if (targetUser.vip === true) {
        user.vip = true
        targetUser.banned = false
        conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }})
        return conn.reply(m.chat, 'Cannot ban them because they are a special member', m)
    }
    
    // Parse duration
    let expiry = 0
    if (duration) {
        let value = parseInt(duration)
        let unit = duration.slice(-1).toLowerCase()
        
        switch(unit) {
            case 's': // seconds
                expiry = value * 1000
                break
            case 'm': // minutes
                expiry = value * 60 * 1000
                break
            case 'h': // hours
                expiry = value * 60 * 60 * 1000
                break
            case 'd': // days
                expiry = value * 24 * 60 * 60 * 1000
                break
            default:
                return conn.reply(m.chat, 'Invalid duration format! Use s(seconds), m(minutes), h(hours), or d(days)', m)
        }
    }
    
    // Set ban status and expiry time
    targetUser.banned = true
    targetUser.banExpiry = expiry ? Date.now() + expiry : 0 // 0 means permanent ban
    
    // Send confirmation message
    let banMessage = expiry 
        ? `User banned for ${duration}`
        : 'User banned permanently'
    
    conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
    conn.reply(m.chat, banMessage, m)
    
    // Set timeout to unban user if duration is specified
    if (expiry) {
        setTimeout(() => {
            targetUser.banned = false
            targetUser.banExpiry = 0
            conn.reply(m.chat, `Ban has expired for ${who.split('@')[0]}`, m)
        }, expiry)
    }
}

handler.help = ['ban']
handler.tags = ['owner']
handler.command = /^ban$/i
handler.owner = true

module.exports = handler