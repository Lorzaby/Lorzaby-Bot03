const axios = require('axios');
const Jimp = require('jimp');
const fs = require('fs');

async function before(m, { conn, participants }) {
    conn.autosholat = conn.autosholat ? conn.autosholat : {};
    let lokasi = 'DKI Jakarta dan sekitarnya.';
    let id = m.chat;

    // Initialize notification tracking for each prayer time
    if (!conn.autosholat[id]) {
        let jdwl = await jadwalsholat(lokasi);
        conn.autosholat[id] = {
            jdwl,
            notified: {
                shubuh: false,
                dhuhur: false,
                ashar: false,
                maghrib: false,
                isya: false
            }
        };
    }

    // Generate prayer schedule image if not exists
    if (!fs.existsSync('./src/jdw.png')) {
        let jdw = conn.autosholat[id].jdwl;
        await image(jdw.shubuh, jdw.dhuhur, jdw.ashar, jdw.maghrib, jdw.isya, lokasi);
    }

    const date = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

    // Check each prayer time
    for (const [sholat, waktu] of Object.entries(conn.autosholat[id].jdwl)) {
        if (timeNow === waktu && !conn.autosholat[id].notified[sholat.toLowerCase()]) {
            // Send notification
            await conn.sendMessage(m.chat, {
                audio: {
                    url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
                },
                mimetype: 'audio/mp4',
                ptt: true,
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        mediaType: 1,
                        mediaUrl: '',
                        title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
                        body: `🕒 ${waktu}`,
                        sourceUrl: 'https://chat.whatsapp.com/Jyatvh2vxKlEIEkHS7KVxX',
                        thumbnail: await fs.promises.readFile('./src/jdw.png'),
                        renderLargerThumbnail: true
                    }
                }
            }, {
                quoted: m
            });

            // Mark as notified
            conn.autosholat[id].notified[sholat.toLowerCase()] = true;

            // Reset notifications at midnight (00:00)
            if (timeNow === '00:00') {
                conn.autosholat[id].notified = {
                    shubuh: false,
                    dhuhur: false,
                    ashar: false,
                    maghrib: false,
                    isya: false
                };
                
                // Update prayer schedule for the new day
                conn.autosholat[id].jdwl = await jadwalsholat(lokasi);
                
                // Regenerate prayer schedule image
                if (fs.existsSync('./src/jdw.png')) {
                    await fs.promises.unlink('./src/jdw.png');
                }
                await image(
                    conn.autosholat[id].jdwl.shubuh,
                    conn.autosholat[id].jdwl.dhuhur,
                    conn.autosholat[id].jdwl.ashar,
                    conn.autosholat[id].jdwl.maghrib,
                    conn.autosholat[id].jdwl.isya,
                    lokasi
                );
            }
        }
    }
}

exports.before = before;
exports.disabled = false;

async function jadwalsholat(kota) {
    try {
        const { data } = await axios.get(`https://api.aladhan.com/v1/timingsByCity?city=${kota}&country=Indonesia&method=8`);

        const result = {
            shubuh: data.data.timings.Fajr,
            dhuhur: data.data.timings.Dhuhr,
            ashar: data.data.timings.Asr,
            maghrib: data.data.timings.Maghrib,
            isya: data.data.timings.Isha
        };
        return result;
    } catch (e) {
        return 'eror 404';
    }
}

async function image(sh, dh, as, ma, is, lok) {
    const image = await Jimp.read('https://files.catbox.moe/w2p1j3.png');
    const font = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);
    const wil = await Jimp.loadFont(Jimp.FONT_SANS_64_BLACK);

    image.print(font, 550, 223, sh);
    image.print(font, 550, 321, dh);
    image.print(font, 550, 392, as);
    image.print(font, 550, 481, ma);
    image.print(font, 550, 571, is);
    image.print(wil, 870, 391, lok);

    await image.writeAsync('./src/jdw.png');
}