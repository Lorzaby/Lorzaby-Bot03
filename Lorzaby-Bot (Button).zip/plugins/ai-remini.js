const fetch = require('node-fetch');
const uploadImage = require("../lib/uploadFile");

async function handler(m, { conn, usedPrefix, command }) {
  try {
    // Memberikan reaksi 🕒 ketika memproses
    await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (/^image/.test(mime) && !/webp/.test(mime)) {
      const img = await q.download();
      const out = await uploadImage(img);
      const api = await fetch(`https://api.betabotz.eu.org/api/tools/remini?url=${out}&apikey=UssanoziLorzabyKey`);
      const image = await api.json();
      const { url } = image;

      // Mengirim gambar hasil dengan caption "Powered by Lorzaby" dan memberikan reaksi ✅ ketika berhasil
      await conn.sendFile(m.chat, url, null, '𝙇𝙤𝙧𝙯𝙖𝙗𝙮 𝙒𝙝𝙖𝙩𝙨𝘼𝙥𝙥 𝘽𝙤𝙩', m);
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } else {
      m.reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau tag gambar yang sudah dikirim.`);
    }
  } catch (e) {
    console.error(e);

    // Memberikan reaksi ❌ ketika gagal
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply(`Identifikasi gagal. Silakan coba lagi.`);
  }
}

handler.help = ["remini", "hd"];
handler.tags = ['tools'];
handler.command = ["remini", "hd"];
handler.premium = false;
handler.limit = true;

module.exports = handler;