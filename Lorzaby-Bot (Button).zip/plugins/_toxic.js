/* 

const axios = require('axios');

const handler = async (m, { conn }) => {
  let audio = {
    audio: { url: 'https://pomf2.lain.la/f/ynks4izf.mp3' },
    mimetype: 'audio/mp4',
    ptt: true,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: 'Jangan toxic om 😠', // Assuming wm and botdate are predefined variables
        body: 'Lorzaby', // Assuming wm and botdate are predefined variables
        sourceUrl: '',
        thumbnail: (await axios.get('https://telegra.ph/file/32e3b521faee1d02251b6.jpg', { responseType: 'arraybuffer' })).data,
        renderLargerThumbnail: true
      }
    }
  };

  conn.sendMessage(m.chat, audio, { quoted: m });
};

handler.customPrefix = /^(anj|anjg|anjing|babi|bangsat|bgsat|bngst|kntl|kontol|kntol|memek|mek|bgst|tai|gblk|goblok|gblok|tolol|tol|idiot|pqi|bajingan|bjnk|bacot|bct|puki|pukimak|asw|asu|ngentot|ngntot|ngntd|pantek|pntk|bego|bgo|kampret|kmprt|kimak|kmk|monyet|mnt|gembel|gmbl|sampah|smph|sinting|sntg|peler|pler|jancok|jancuk|jancok|janco|jnck|dancok|danco|dnjk|setan|stn|iblis|ibls|jahanam|monyet|ngntt|pntk|pentek|pecun|pepek|ppk|toket|tkt|tod|dongo)$/i;
handler.command = new RegExp();
module.exports = handler;