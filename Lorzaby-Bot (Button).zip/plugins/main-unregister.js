const { createHash } = require('crypto')
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

let handler = async function (m, { args, conn }) {
  if (!args[0]) {
    // Thumbnail untuk pesan "Serial Number Kosong!"
    let media = await prepareWAMessageMedia({
      image: { url: 'https://files.catbox.moe/jjm2jj.jpg' } // Gambar thumbnail
    }, { upload: conn.waUploadToServer });

    let buttonMessage = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2,
            "mentionedJid": [m.sender]
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
              mentionedJid: [m.sender]
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: `Serial Number Kosong!`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: 'Silahkan cek serial number anda terlebih dahulu.'
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: true,
              ...media
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  "name": "quick_reply",
                  "buttonParamsJson": `{"display_text":"Cek Serial Number","id": ".ceksn"}`
                }
              ],
            })
          })
        }
      }
    }, {});

    await conn.relayMessage(m.chat, buttonMessage.message, {
      messageId: buttonMessage.key.id
    });
    return;
  }

  let user = global.db.data.users[m.sender]
  let sn = createHash('md5').update(m.sender).digest('hex')
  if (args[0] !== sn) throw 'Serial Number Salah'
  let __waktuh = (new Date - global.db.data.users[m.sender].unreglast)
  let _waktuh = (+1000 - __waktuh)
  let waktuh = clockString(_waktuh)
  if (new Date - global.db.data.users[m.sender].unreglast > +1000) {
    user.unreglast = new Date * 1
    user.registered = false

    // Thumbnail untuk pesan "Unregister Berhasil!"
    let mediaUnreg = await prepareWAMessageMedia({
      image: { url: 'https://files.catbox.moe/jjm2jj.jpg' } // Gambar thumbnail
    }, { upload: conn.waUploadToServer });

    let buttonUnregMessage = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2,
            "mentionedJid": [m.sender]
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
              mentionedJid: [m.sender]
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: `Unregister Berhasil!`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: 'Proses unregister telah selesai! Silahkan klik tombol dibawah untuk register ulang.'
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: true,
              ...mediaUnreg
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  "name": "quick_reply",
                  "buttonParamsJson": `{"display_text":"Verify","id": ".verify"}`
                }
              ],
            })
          })
        }
      }
    }, {});

    await conn.relayMessage(m.chat, buttonUnregMessage.message, {
      messageId: buttonUnregMessage.key.id
    });

  } else {
    m.reply(`Kamu sudah melakukan *unregister*\nMohon tunggu ${waktuh} untuk bisa melakukan *unregister* kembali.`)
  }
}

handler.help = ['unreg']
handler.tags = ['main']
handler.command = /^unreg(ister)?$/i
handler.register = true

module.exports = handler

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}