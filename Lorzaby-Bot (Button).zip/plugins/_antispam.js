const { performance } = require('perf_hooks');

const SPAM_THRESHOLD = 5;  // Maksimal 5 kali spam
const COOLDOWN_DURATION = 5000;
const BAN_DURATION = 1800000;  // 30 menit dalam milliseconds
const OWNER_NUMBER = '6285381310740@s.whatsapp.net'; // Nomor owner

async function before(m) {
    const users = global.db.data.users;
    const chats = global.db.data.chats;
    
    // Cek prefix dan command
    let isCommand = false;
    const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#%^&.\/\\©^]/; // Sesuaikan dengan prefix yang digunakan
    
    // Deteksi apakah pesan mengandung prefix dan command
    if (m.text) {
        const prefix = prefixRegex.test(m.text) ? m.text.match(prefixRegex)[0] : '';
        isCommand = prefix && m.text.length > prefix.length;
    }

    // Jika bukan command, skip pengecekan spam
    if (!isCommand) return;

    // Cek apakah pengirim adalah owner (langsung dengan nomor)
    const isOwner = m.sender === OWNER_NUMBER;
    
    if (
        !m.isBaileys &&
        !['protocolMessage', 'pollUpdateMessage', 'reactionMessage'].includes(m.mtype) &&
        m.msg &&
        m.message &&
        !users[m.sender].banned &&
        !chats[m.chat].isBanned
    ) {
        this.spam = this.spam || {};
        this.spam[m.sender] = this.spam[m.sender] || {
            count: 0,
            lastspam: 0
        };

        const now = performance.now();
        const timeDifference = now - this.spam[m.sender].lastspam;

        // Skip pengecekan spam untuk owner
        if (isOwner) {
            this.spam[m.sender].lastspam = now;
            return;
        }

        if (timeDifference < COOLDOWN_DURATION) {
            this.spam[m.sender].count++;

            if (this.spam[m.sender].count >= SPAM_THRESHOLD) {
                users[m.sender].banned = true;
                this.spam[m.sender].lastspam = now + BAN_DURATION;

                setTimeout(() => {
                    users[m.sender].banned = false;
                    this.spam[m.sender].count = 0;
                    m.reply(`Hukuman dari spam selesai, anda bisa menggunakan bot kembali.`);
                }, BAN_DURATION);

                return m.reply(`Anda terdeteksi melakukan spam command bot! Anda dihukum banned selama 30 menit.`);
            }
        } else {
            this.spam[m.sender].count = 0;
        }

        this.spam[m.sender].lastspam = now;
    }
}

module.exports = { before };