let search = require("yt-search");
let axios = require("axios");

let handler = async (m, { conn, text }) => {
    if (!text) throw `*Example:* .play2 cupid`;
    
    // Menambahkan emoji reaction ⏳
    await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

    try {
        // Mencari video berdasarkan teks atau link
        const look = await search(text);
        const convert = look.videos[0];
        if (!convert) throw 'Audio Tidak Ditemukan';
        if (convert.seconds >= 3600) {
            return conn.reply(m.chat, 'Video lebih dari 1 jam!', m);
        } else {
            let audioUrl;
            try {
                // Mengambil link audio menggunakan API YouTube
                audioUrl = await youtube(convert.url);
            } catch (e) {
                conn.reply(m.chat, 'Wait', m);
                audioUrl = await youtube(convert.url);
            }

            // Menyusun pesan dengan audio, link, dan thumbnail
            let messageOptions = {
                audio: {
                    url: audioUrl.result.mp3
                }, // Mengirim audio dalam format MP3
                mimetype: 'audio/mpeg',
                fileName: `${convert.title}.mp3`, // Nama file audio
                contextInfo: {
                    externalAdReply: {
                        title: convert.title, // Judul video/audio
                        body: "", // Bisa ditambahkan teks deskripsi jika diinginkan
                        thumbnailUrl: convert.image, // URL thumbnail video YouTube
                        sourceUrl: convert.url, // URL asli YouTube
                        mediaType: 1, // Tipe media: video/audio
                        renderLargerThumbnail: true, // Menampilkan thumbnail lebih besar
                        showAdAttribution: true // Menampilkan informasi tambahan
                    }
                }
            };

            // Mengirim pesan dengan audio dan thumbnail
            await conn.sendMessage(m.chat, messageOptions, { quoted: m });
        }
    } catch (e) {
        conn.reply(m.chat, `*Error:* ` + e.message, m);
    }
};

handler.command = handler.help = ['play2'];
handler.tags = ['music'];
handler.limit = 5
handler.premium = false;

module.exports = handler;

// Fungsi untuk mengambil data audio dari YouTube
async function youtube(url) {
    try {
        const { data } = await axios.get("https://api.betabotz.eu.org/api/download/yt?url=" + url + "&apikey=" + btc);
        return data;
    } catch (e) {
        return e;
    }
}