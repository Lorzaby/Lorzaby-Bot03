let qrcode = require("qrcode")
let handler  = async (m, { conn, text }) => {
  if (!text) throw `*Example:* ${usedPrefix+command} *<text>*`
  conn.sendFile(m.chat, await qrcode.toDataURL(text.slice(0, 2048), { scale: 8 }), 'qrcode.png', done, m)
}

handler.help = ['qr']
handler.tags = ['tools']
handler.command = /^qr(code)?$/i

handler.limit = true
handler.fail = null

module.exports = handler