let handler = async (m, { conn, participants }) => {
  // if (participants.map(v=>v.jid).includes(global.conn.user.jid)) {
    global.db.data.chats[m.chat].isBanned = true
    conn.reply(m.chat, 'Oke', m)
  // } else m.reply('There is a host number here...')
}
handler.customPrefix = /^(banchat|.banchat)$/i
handler.command = new RegExp
handler.owner = true

module.exports = handler