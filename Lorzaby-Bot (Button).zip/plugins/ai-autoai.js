const axios = require('axios');
const moment = require('moment-timezone');

let globalAutoAI = false; // Flag untuk mengaktifkan Auto AI untuk semua pengguna
let sessionTimeout = 5 * 60 * 1000; // 5 menit

// Simpan session di memory untuk sementara
const sessionStore = {};

// Fungsi untuk membersihkan session setelah 5 menit
const clearSession = (sender) => {
    if (sessionStore[sender]) {
        setTimeout(() => {
            delete sessionStore[sender];
        }, sessionTimeout);
    }
};

let handler = async (m, { conn, text }) => {
    if (!text) throw `*Example:* .autoai *<on/off>*`;

    if (text === "on") {
        globalAutoAI = true;  // Mengaktifkan autoAI untuk semua orang
        m.reply("AutoAI has been enabled for all users.");
    } else if (text === "off") {
        globalAutoAI = false; // Mematikan autoAI
        m.reply("AutoAI has been disabled.");
    }
};

// Filter untuk private chat saja, dan hapus session setelah 5 menit
handler.before = async (m, { conn }) => {
        if (
            m.text.startsWith(".") ||
            m.text.startsWith("#") ||
            m.text.startsWith("!") ||
            m.text.startsWith("/") ||
            m.text.startsWith("\\/")
        ) return;
    if (!globalAutoAI) return;  // Jika global AutoAI tidak aktif, abaikan semua pesan
    if (m.isBaileys && m.fromMe) return;
    if (!m.text || m.isGroup) return;  // Hanya merespon di private chat

    const sender = m.sender;
    
    // Jika session belum ada, buat session baru
    if (!sessionStore[sender]) {
        sessionStore[sender] = {
            pesan: []
        };
    }

    // Menyimpan pesan pengguna ke dalam session
    sessionStore[sender].pesan.push(m.text);

    // Logika AI: Menyambungkan ke API AI
    await conn.sendMessage(m.chat, { react: { text: `🤔`, key: m.key }});
    
    // Mendapatkan waktu sekarang di zona waktu WIB
    const moment = require('moment-timezone');

    const currentDateTime = moment.tz("Asia/Jakarta").format('YYYY-MM-DD HH:mm:ss'); // Format tanggal dan waktu
console.log(currentDateTime);
        
    const messages = [
        ...sessionStore[sender].pesan, // Menggunakan percakapan sebelumnya dari session
        `Nama kamu adalah Lorzaby WhatsApp Bot, sebuah sistem bot yang dikembangkan oleh Ussanozi Lorzaby selaku Owner kamu. Kamu adalah kawan bicara yang asik dan seru, kamu punya kemampuan untuk bercanda, memberikan jawaban pintar, serta menyesuaikan gaya bicaramu sesuai dengan suasana. Di dalam obrolan kamu bisa jadi teman yang ramah, tapi saat ada yang butuh bantuan, aku akan serius memberikan solusi. Lawan bicara kamu adalah ${m.name}. Gunakan zona waktu ${currentDateTime} jika ada yang menanyakan waktu.`
    ];

    try {
        const response = await axios.get(`https://api.betabotz.eu.org/api/search/openai-logic`, {
            params: {
                text: m.text,
                logic: JSON.stringify(messages),
                apikey: `${global.btc}`
            }
        });

        const responseData = response.data;
        if (responseData.status) {
            await conn.sendMessage(m.chat, { react: { text: `😎`, key: m.key }});
            m.reply(responseData.message);
        } else {
            throw new Error("API response status is false");
        }
    } catch (error) {
        console.error("Error fetching data:", error);
        throw error;
    }

    // Set timer untuk menghapus session setelah 5 menit tidak ada aktivitas
    clearSession(sender);
};

handler.command = ['autoai'];
handler.tags = ["ai"];
handler.help = ['autoai'].map(a => a + " *<on/off>*");
handler.owner = true

module.exports = handler;