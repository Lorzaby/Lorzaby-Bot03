let handler = async (m, { conn, text, args, command }) => {
    let users = global.db.data.users;
    
    // Handle unban all command
    if (command === 'unbanall') {
        let bannedCount = 0;
        
        // Count banned users first
        for (let user in users) {
            if (users[user].banned) bannedCount++;
        }
        
        // If no banned users found
        if (bannedCount === 0) {
            return conn.reply(m.chat, '🔍 Tidak ada user yang dibanned saat ini.', m);
        }
        
        // Unban all users
        for (let user in users) {
            if (users[user].banned) {
                users[user].banned = false;
            }
        }
        
        conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
        return conn.reply(m.chat, `✅ Berhasil unban semua user\n📊 Total: ${bannedCount} user`, m);
    }
    
    // Handle single user unban
    if (command === 'unban') {
        if (!text) throw '*Example:* .unban 6285381310740'
        let who;
        if (m.isGroup) {
            who = m.mentionedJid[0];
        } else {
            who = m.chat;
        }
        
        if (!who) throw 'Tag yang ingin di unban Bot';
        
        // Check if user exists in database
        if (!users[who]) {
            throw 'User tidak ditemukan dalam database';
        }
        
        // Check if user is already unbanned
        if (!users[who].banned) {
            throw 'User tersebut tidak dalam status banned';
        }
        
        // Unban the user
        users[who].banned = false;
        
        conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
        conn.reply(m.chat, `✅ Berhasil unban @${who.split('@')[0]}`, m, {
            mentions: [who]
        });
    }
}

handler.help = ['unban', 'unbanall']
handler.tags = ['owner']
handler.command = /^(unban|unbanall)$/i
handler.owner = true
handler.admin = false
handler.group = false
handler.botAdmin = false

module.exports = handler