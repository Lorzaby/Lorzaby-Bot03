const axios = require('axios');
const cheerio = require('cheerio');
const { proto } = require('@whiskeysockets/baileys');
const { generateWAMessageContent, generateWAMessageFromContent } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `Masukan URL yang ingin di unduh!`;
    
    try {
        // Kirim pesan proses
        await m.reply('⏳ Sedang diproses...');
        
        // Validasi URL
        let url = args[0];
        if (!url.match(/https?:\/\/(www\.)?(instagram\.com|facebook\.com)/i)) {
            throw 'URL yang anda masukan tidak valid!';
        }

        // Fungsi untuk membuat pesan gambar
        async function createImage(url) {
            const { imageMessage } = await generateWAMessageContent({
                image: {
                    url
                }
            }, {
                upload: conn.waUploadToServer
            });
            return imageMessage;
        }

        // Fungsi download menggunakan yt1s
        const { data } = await axios.post('https://yt1s.io/api/ajaxSearch', 
            new URLSearchParams({ p: 'home', q: url, w: '', lang: 'en' }),
            {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                }
            }
        );

        if (data.status !== 'ok') throw 'Gagal mendapatkan data dari server!';

        const $ = cheerio.load(data.data);
        const downloads = $('a.abutton.is-success.is-fullwidth.btn-premium')
            .map((_, el) => ({
                title: $(el).attr('title'),
                url: $(el).attr('href')
            }))
            .get();

        if (!downloads || downloads.length === 0) {
            throw 'Tidak dapat menemukan media untuk diunduh';
        }

        // Proses media
        let push = [];
        let i = 1;

        for (const dl of downloads) {
            try {
                const response = await axios.get(dl.url, { responseType: 'arraybuffer' });
                const buffer = Buffer.from(response.data, 'binary');
                const mimeType = response.headers['content-type'];

                if (mimeType.includes('image')) {
                    // Untuk gambar, tambahkan ke carousel
                    push.push({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `Gambar ${i++}`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: global.botname
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            title: dl.title,
                            hasMediaAttachment: true,
                            imageMessage: await createImage(dl.url)
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [
                                {
                                    "name": "cta_url",
                                    "buttonParamsJson": `{"display_text":"Owner","url":"https://wa.me/6285381310740","merchant_url":"https://wa.me/6285381310740"}`
                                }
                            ]
                        })
                    });
                } else {
                    // Untuk video dan tipe file lainnya, kirim seperti biasa
                    if (mimeType.includes('video')) {
                        await conn.sendFile(m.chat, buffer, 'video.mp4', `*Title:* ${dl.title}`, m);
                    } else {
                        await conn.sendFile(m.chat, buffer, dl.title, `*Title:* ${dl.title}`, m);
                    }
                }
            } catch (err) {
                console.error(`Error processing media:`, err);
                await m.reply(`Gagal memproses media!`);
            }
        }

        // Jika ada gambar dalam carousel, kirim sebagai satu pesan
        if (push.length > 0) {
            const bot = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: "*Untuk menyimpan gambar:* Klik salah satu foto, klik titik tiga di pojok kanan atas, klik simpan."
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: global.botname
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: false
                            }),
                            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                cards: [
                                    ...push
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m });

            await conn.relayMessage(m.chat, bot.message, {
                messageId: bot.key.id
            });
        }

    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat mengunduh media!\n\n' + error.message);
    }
};

handler.help = ['ig <url>'];
handler.tags = ['downloader'];
handler.command = /^(ig)$/i;
handler.limit = true;
handler.premium = false;

module.exports = handler;