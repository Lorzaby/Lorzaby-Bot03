const linkRegex = /^(anj|anjg|anjing|babi|bangsat|bgsat|bngst|kntl|kontol|kntol|memek|mek|bgst|tai|gblk|goblok|gblok|tolol|tol|idiot|pqi|bajingan|bjnk|bacot|bct|puki|pukimak|asw|asu|ngentot|ngntot|ngntd|pantek|pntk|bego|bgo|kampret|kmprt|kimak|kmk|monyet|mnt|gembel|gmbl|sampah|smph|sinting|sntg|peler|pler|jancok|jancuk|jancok|janco|jnck|dancok|danco|dnjk|setan|stn|iblis|ibls|jahanam|monyet|ngntt|pntk|pentek|pecun|pepek|ppk|toket|tkt|tod|dongo)$/i;

module.exports.before = async function(m, { conn, command, text }) {
    const owner = "6285381310740@s.whatsapp.net"; // ganti dengan nomor owner
    if (m.sender == owner) return; // jika sender adalah owner, maka tidak akan dihapus
    
    const deleteMessage = { delete: { remoteJid: m.key.remoteJid, fromMe: false, id: m.key.id, participant: [m.sender] } };
    
    if (m.isBaileys && m.fromMe) return;
    let chat = global.db.data.chats[m.chat];
    let isGroupToxic = linkRegex.exec(m.text);
    if (chat.antiToxic && isGroupToxic && m.isGroup) {
        await conn.sendMessage(m.chat, { delete: m.key });
    }
    return !0;
};