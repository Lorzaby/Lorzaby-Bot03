const { createHash } = require('crypto');
const fetch = require('node-fetch');

let handler = async function(m, { text, usedPrefix, conn }) { // Tambahkan `conn` sebagai parameter
    let user = global.db.data.users[m.sender];
    let name = await conn.getName(m.sender);

    // Mendapatkan foto profil pengguna atau default jika tidak ada
    let pp = await conn.profilePictureUrl(m.sender, 'image').catch(() => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");

    // Cek apakah pengguna sudah terdaftar
    if (user.registered) throw 'Nomor Kamu Sudah Terverifikasi';

    // Memperbarui data pengguna dengan waktu registrasi dan status registrasi
    user.regTime = +new Date();
    user.registered = true;

    // Membuat serial number untuk pengguna
    let sn = createHash('md5').update(m.sender).digest('hex');

    // Membuat pesan konfirmasi registrasi
    let capt = `*Name:* ${name}\n`;
    capt += `*Age:* -\n`; // Tidak menanyakan umur
    capt += `*Number:* +${m.sender.split('@')[0]}\n`;
    
    let today = new Date();
    let tanggal = today.toLocaleDateString("id-ID", {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });

    capt += `*Date:* ${tanggal}\n\n`;
    capt += `> Powered By WhatsApp`;

    // Membuat tampilan yang serupa dengan pesan "Register Success"
    let kemii = '0@s.whatsapp.net';
    let v4 = { key: { participant: kemii, remoteJid: "0@s.whatsapp.net" }, message: { conversation: "Verification Success" } };

    // Mengirim pesan dengan tampilan seperti register
    await conn.sendMessage(m.chat, {
        text: capt,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: 'Lorzaby WhatsApp Bot',
                body: 'Version: 9.9.9',
                thumbnailUrl: pp,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: v4 }); // Menggunakan objek `v4` sebagai quoted message
};

handler.help = ['verify'];
handler.tags = ['main'];
handler.command = /^(verify)$/i;

module.exports = handler;