const axios = require("axios")
const { v4: uuidv4 } = require('uuid')

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command,
    text
}) => {
    if (!text) return m.reply("*Example:* .feloai muslim")
    await m.react('🕒')
    
    try {
        const headers = {
            "Accept": "*/*",
            "User-Agent": "Postify/1.0.0",
            "Content-Encoding": "gzip, deflate, br, zstd",
            "Content-Type": "application/json",
        }

        const payload = {
            query: text,
            search_uuid: uuidv4().replace(/-/g, ''),
            search_options: { langcode: "id-MM" },
            search_video: true,
        }
        
        const response = await axios.post("https://api.felo.ai/search/threads", payload, {
            headers,
            timeout: 30000,
            responseType: 'text',
        })
        
        const result = processResponse(response.data)
        
        if (!result) return m.reply('Gagal mendapatkan respons dari FeloAI')
        
        let finalResponse = `*FeloAI Response:*\n\n${result.answer}`
        
        if (result.source && result.source.length > 0) {
            finalResponse += '\n\n*Sources:*'
            result.source.forEach((src, i) => {
                finalResponse += `\n${i + 1}. ${src.title || 'Untitled'}`
                if (src.url) finalResponse += `\n   ${src.url}`
            })
        }
        
        await conn.sendMessage(m.chat, {
            text: finalResponse,
            contextInfo: {
                externalAdReply: {
                    title: 'Search Engine AI Felo',
                    thumbnailUrl: 'https://pomf2.lain.la/f/0qwbaoo.jpg',
                    sourceUrl: 'https://bento.me/lorzaby',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })
        
    } catch (error) {
        console.error('Error details:', error.response?.data || error.message)
        m.reply("Terjadi kesalahan saat memproses permintaan. Silakan coba lagi.")
    }
}

function processResponse(badi) {
    const result = { answer: '', source: [] }
    badi.split('\n').forEach(line => {
        if (line.startsWith('data:')) {
            try {
                const data = JSON.parse(line.slice(5).trim())
                if (data.data) {
                    if (data.data.text) {
                        result.answer = data.data.text.replace(/\[\d+\]/g, '')
                    }
                    if (data.data.sources) {
                        result.source = data.data.sources
                    }
                }
            } catch (e) {
                console.error(e)
            }
        }
    })
    return result
}

handler.help = ["feloai"].map(v => v + ' *<text>*')
handler.tags = ["ai"]
handler.command = /^(feloai|felo)$/i
handler.premium = false
handler.limit = true;
handler.register = true

module.exports = handler