const captcha = require('@neoxr/captcha');
const crypto = require("crypto");
const PhoneNumber = require('awesome-phonenumber');
const fetch = require("node-fetch");
const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

const handler = async (m, { conn, text, usedPrefix, command }) => {
    conn.registrasi = conn.registrasi ? conn.registrasi : {};
    if (conn.registrasi[m.chat]?.[m.sender]) return m.reply('You are requesting verification!');
    let user = global.db.data.users[m.sender];
    let indraa = await conn.getName(m.sender);
    if (user.registered === true) return conn.reply(m.chat, 'Nomor Kamu Sudah Terverifikasi', m);
    let sn = crypto.createHash("md5").update(m.sender).digest("hex");
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.fromMe ? conn.user.jid : m.sender;
    let newCaptcha = captcha();
    let image = Buffer.from(newCaptcha.image.split(',')[1], 'base64');

    let confirm = "Silahkan salin kode kamu dengan mengklik tombol dibawah lalu kirim ke dalam chat ini.";
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: confirm
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: ""
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "cta_copy",
                                "buttonParamsJson": `{"display_text":"Salin Code","id":"123456789","copy_code":"${newCaptcha.value}"}`
                            }
                        ],
                    })
                })
            }
        }
    }, { quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    conn.registrasi[m.chat] = {
        ...conn.registrasi[m.chat],
        [m.sender]: {
            message: m,
            sender: m.sender,
            otp: newCaptcha.value,
            user,
            key: msg.key,
            timeout: setTimeout(() => {
                conn.sendMessage(m.chat, { delete: msg.key });
                delete conn.registrasi[m.chat][m.sender];
            }, 60 * 1000)
        }
    };
}

handler.before = async (m, { conn }) => {
    conn.registrasi = conn.registrasi ? conn.registrasi : {};
    if (m.isBaileys) return;
    if (!conn.registrasi[m.chat]?.[m.sender]) return;
    if (!m.text) return;
    let { timeout, otp, message, sender, user, key } = conn.registrasi[m.chat]?.[m.sender];
    if (m.id === message.id) return;
    if (m.id === key.id) return;
    if (m.text === otp) {
        clearTimeout(timeout);
        delete conn.registrasi[m.chat]?.[m.sender];
        let v2 = { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: "Register (2/3)"} }
        let name = await conn.sendInputMessage(m.chat, { text: "Masukan Nama Anda:" }, m.sender, 120000000, v2);
        let v3 = { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: "Register (3/3)"} }
        let age; while (isNaN(age)) age = parseInt(await conn.sendInputMessage(m.chat, { text: "Masukan Umur Anda:" }, m.sender, 120000000, v3));
        user.name = name.trim();
        user.age = age;
        user.regTime = +new Date;
        user.registered = true;
        let indraa = '0@s.whatsapp.net'
        let v4 = { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: "Registration Success"} }
        let today = new Date();
        let tanggal = today.toLocaleDateString("id-ID", {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
        let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://files.catbox.moe/jjm2jj.jpg");
        let teks = '';
        teks += '*Name:* ' + `${name}\n`;
        teks += '*Age:* ' + `${age}\n`;
        teks += '*Number:* ' + `${PhoneNumber('+' + m.sender.split('@')[0]).getNumber('international')}\n`;
        teks += '*Date:* ' + `${tanggal}\n\n`;
        teks += '> Powered By WhatsApp';
        await conn.sendMessage(m.chat, {
            text: teks,
            contextInfo: {
                mentionedJid: [indraa],
                externalAdReply: {
                    showAdAttribution: true,
                    title: 'Lorzaby WhatsApp Bot',
                    body: 'Version 9.9.9',
                    thumbnailUrl: ppUrl,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: v4 });
        let asu = 'Registers Notifications\n\n'
        asu += `*Name:* ${name}\n`
        asu += `*Age:* ${age}\n`
        asu += `*Tags:* @${m.sender.replace(/@.+/g, '')}`
        await conn.notify(asu);
    } else {
        await m.reply(`Your verification code is wrong.`);
        clearTimeout(timeout);
        await conn.sendMessage(m.chat, { delete: key });
        delete conn.registrasi[m.chat]?.[m.sender];
    }
}

handler.help = ["register", "daftar"];
handler.tags = ["start"];
handler.command = /^(register|daftar)$/i;

module.exports = handler;