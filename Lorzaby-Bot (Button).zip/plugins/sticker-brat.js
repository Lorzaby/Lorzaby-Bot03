const { sticker } = require('../lib/sticker')
const uploadImage = require('../lib/uploadFile')

let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan teks yang ingin ditulis!'
    
    try {
        // Menampilkan reaksi loading
        await conn.sendMessage(m.chat, {
            react: {
                text: '🕒',
                key: m.key,
            }
        });

        const { createCanvas, loadImage, registerFont } = require('canvas')
        const fs = require('fs')

        // Register font
        const fontPath = './src/ArialNova.ttf'
        try {
            registerFont(fontPath, { family: 'ArialNova' })
        } catch (error) {
            console.error('Error loading font:', error)
            throw 'Font ArialNova tidak ditemukan!'
        }

        // Load dan cache background image
        const backgroundCache = new Map()
        async function getBackgroundImage() {
            if (backgroundCache.has('main')) {
                return backgroundCache.get('main')
            }

            try {
                const fetch = require('node-fetch')
                const response = await fetch('https://files.catbox.moe/389wha.jpg')
                if (!response.ok) throw new Error('Failed to fetch image')
                const buffer = await response.buffer()
                const tempPath = './src/temp.jpg'
                fs.writeFileSync(tempPath, buffer)
                const image = await loadImage(tempPath)
                backgroundCache.set('main', image)
                return image
            } catch (error) {
                console.error('Error fetching online image:', error)
                const fallbackImage = await loadImage('./src/background.jpg')
                backgroundCache.set('main', fallbackImage)
                return fallbackImage
            }
        }

        // Load background
        const image = await getBackgroundImage()

        // Create canvas dengan ukuran yang optimal
        const maxWidth = 800
        const maxHeight = 600
        const ratio = Math.min(maxWidth / image.width, maxHeight / image.height)
        const width = image.width * ratio
        const height = image.height * ratio
        
        const canvas = createCanvas(width, height)
        const ctx = canvas.getContext('2d')

        // Draw background
        ctx.drawImage(image, 0, 0, width, height)

        // Konfigurasi text styling
        const textConfig = {
            minFontSize: 20,
            maxFontSize: Math.floor(height * 0.15),
            padding: {
                top: Math.floor(height * 0.05),
                left: Math.floor(width * 0.05),
                right: Math.floor(width * 0.05),
                bottom: Math.floor(height * 0.05)
            },
            color: 'black',
            lineHeightFactor: 1.3
        }

        // Function untuk mencari ukuran font optimal
        const findOptimalFontSize = (ctx, text, maxWidth, maxHeight, config) => {
            let fontSize = config.maxFontSize
            const availableWidth = maxWidth - (config.padding.left + config.padding.right)
            const availableHeight = maxHeight - (config.padding.top + config.padding.bottom)
            
            let low = config.minFontSize
            let high = fontSize
            let optimal = low
            
            while (low <= high) {
                fontSize = Math.floor((low + high) / 2)
                ctx.font = `${fontSize}px ArialNova`
                
                const lines = []
                const words = text.split(' ')
                let currentLine = ''
                
                for (const word of words) {
                    const testLine = currentLine + (currentLine ? ' ' : '') + word
                    const metrics = ctx.measureText(testLine)
                    
                    if (metrics.width > availableWidth) {
                        if (currentLine) {
                            lines.push(currentLine)
                            currentLine = word
                        } else {
                            high = fontSize - 1
                            continue
                        }
                    } else {
                        currentLine = testLine
                    }
                }
                if (currentLine) {
                    lines.push(currentLine)
                }
                
                const totalHeight = lines.length * (fontSize * config.lineHeightFactor)
                
                if (totalHeight <= availableHeight) {
                    optimal = fontSize
                    low = fontSize + 1
                } else {
                    high = fontSize - 1
                }
            }
            
            return optimal
        }

        // Function untuk menggambar teks dengan wrapping
        const drawText = (ctx, text, width, height, config) => {
            const availableWidth = width - (config.padding.left + config.padding.right)
            
            const fontSize = findOptimalFontSize(ctx, text, width, height, config)
            ctx.font = `${fontSize}px ArialNova`
            
            const words = text.split(' ')
            const lines = []
            let currentLine = ''
            
            for (const word of words) {
                const testLine = currentLine + (currentLine ? ' ' : '') + word
                const metrics = ctx.measureText(testLine)
                
                if (metrics.width > availableWidth) {
                    if (currentLine) {
                        lines.push(currentLine)
                        currentLine = word
                    } else {
                        lines.push(word)
                        currentLine = ''
                    }
                } else {
                    currentLine = testLine
                }
            }
            if (currentLine) {
                lines.push(currentLine)
            }
            
            const lineHeight = fontSize * config.lineHeightFactor
            ctx.fillStyle = config.color
            
            lines.forEach((line, i) => {
                const y = config.padding.top + (i * lineHeight)
                ctx.fillText(line, config.padding.left, y + fontSize)
            })
        }

        // Draw text
        drawText(ctx, text, width, height, textConfig)

        // Convert canvas ke buffer
        const buffer = canvas.toBuffer('image/png')

        try {
            // Upload gambar dan buat stiker
            const uploadedImage = await uploadImage(buffer)
            const stik = await sticker(false, uploadedImage, 'Lorzaby')
            
            if (stik) {
                await conn.sendFile(m.chat, stik, 'sticker.webp', '', m)
            } else {
                throw 'Gagal membuat stiker'
            }
        } catch (e) {
            console.error('Error creating sticker:', e)
            // Fallback: mencoba membuat stiker langsung dari buffer
            try {
                const stik = await sticker(buffer, false, 'Lorzaby')
                if (stik) {
                    await conn.sendFile(m.chat, stik, 'sticker.webp', '', m)
                } else {
                    throw 'Gagal membuat stiker (fallback)'
                }
            } catch (fallbackError) {
                console.error('Fallback error:', fallbackError)
                throw 'Gagal membuat stiker! Silakan coba lagi.'
            }
        }

    } catch (error) {
        console.error('Error detail:', error)
        throw 'Terjadi kesalahan saat memproses stiker! Silakan coba lagi.'
    }
}

handler.help = ['brat <teks>']
handler.tags = ['tools']
handler.command = /^(brat)$/i
handler.limit = true

module.exports = handler