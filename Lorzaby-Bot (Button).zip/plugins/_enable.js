let handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
  let isEnable = /true|enable|(turn)?on|1/i.test(command);
  let chat = global.db.data.chats[m.chat];
  let user = global.db.data.users[m.sender];
  let set = global.db.data.settings[conn.user.jid];
  let type = (args[0] || '').toLowerCase();
  let isAll = false;
  let isUser = false;
  
  const more = String.fromCharCode(8206)
  const readMore = more.repeat(4001)

  switch (type) {
    case 'welcome':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn);
          throw false;
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn);
        throw false;
      }
      chat.welcome = isEnable;
      break;
    case 'ngetik':
      if (!isROwner) {
        global.dfail('rowner', m, conn);
        throw false;
      }
      chat.ngetik = isEnable;
      break;
    case 'simi':
      if (!(isAdmin || isOwner)) {
        global.dfail('admin', m, conn);
        throw false;
      }
      chat.simi = isEnable;
      break;
    case 'antispam':
      if (!isROwner && !isOwner) {
        global.dfail('owner', m, conn);
        throw false;
      }
      chat.antiSpam = isEnable;
      break;
    case 'antilink':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn);
          throw false;
        }
      }
      chat.antiLink = isEnable;
      break;
    case 'antisticker':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn);
          throw false;
        }
      }
      chat.antiSticker = isEnable;
      break;
    case 'antifoto':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn);
          throw false;
        }
      }
      chat.antiFoto = isEnable;
      break;
    case 'antitoxic':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn);
          throw false;
        }
      }
      chat.antiToxic = isEnable;
      break;
    case 'autolevelup':
      isUser = true;
      user.autolevelup = isEnable;
      break;
    case 'autoread':
      isAll = true;
      if (!isROwner) {
        global.dfail('rowner', m, conn);
        throw false;
      }
      global.opts['autoread'] = isEnable;
      break;
    case 'pconly':
    case 'privateonly':
      isAll = true;
      if (!isROwner) {
        global.dfail('rowner', m, conn);
        throw false;
      }
      global.opts['pconly'] = isEnable;
      break;
    case "ownergroup":
      if (!isROwner || !isOwner) {
        global.dfail("owner", m, conn);
        throw false;
      }
      set.onlymember = isEnable;
      break;
    case 'gconly':
    case 'grouponly':
      isAll = true;
      if (!isROwner) {
        global.dfail('rowner', m, conn);
        throw false;
      }
      global.opts['gconly'] = isEnable;
      break;
    case 'swonly':
    case 'statusonly':
      isAll = true;
      if (!isROwner) {
        global.dfail('rowner', m, conn);
        throw false;
      }
      global.opts['swonly'] = isEnable;
      break;
    default:
      if (!/[01]/.test(command)) return m.reply(Styles(`
 *G R O U P  -  M E N U*
•  antisticker ${chat.antiSticker ? "(✓)" : "(✗)"}
•  welcome ${chat.welcome ? "(✓)" : "(✗)"}
•  antitoxic ${chat.antiToxic ? "(✓)" : "(✗)"}
•  antilink ${chat.antiLink ? "(✓)" : "(✗)"}
•  antifoto ${chat.antiFoto ? "(✓)" : "(✗)"}
•  ngetik ${chat.ngetik ? "(✓)" : "(✗)"}
•  simi ${chat.simi ? "(✓)" : "(✗)"}

*O W N E R  -  M E N U*
•  ownergroup ${set.onlymember ? "(✓)" : "(✗)"}
•  antispam ${chat.antiSpam ? "(✓)" : "(✗)"}
•  autoread ${global.opts['autoread'] ? "(✓)" : "(✗)"}
•  pconly ${global.opts['pconly'] ? "(✓)" : "(✗)"}
•  gconly ${global.opts['gconly'] ? "(✓)" : "(✗)"}
•  swonly ${global.opts['swonly'] ? "(✓)" : "(✗)"}

*Example:* .on antilink 
`.trim()));
      throw false;
  }
  conn.reply(m.chat, `Fitur ${type} ${isEnable ? 'Aktif' : 'Mati'}`, m);
}
handler.help = ['en', 'dis'].map(v => v + 'able *<option>*');
handler.tags = ['group', 'owner'];
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?o(n|ff)|[01])$/i;

module.exports = handler;