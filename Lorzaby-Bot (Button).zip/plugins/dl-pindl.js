const axios = require("axios");
const FormData = require("form-data");
const cheerio = require("cheerio");

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) throw `*Example:* ${usedPrefix+command} *<url>*`;

    try {
        m.reply(wait);
        const {
            medias,
            title,
            duration
        } = await pindl(text);
        let mp4 = medias.filter(v => v.extension === "mp4");
        
        if (mp4.length !== 0) {
            let sizeMessage = '';
            // Cek apakah global.func dan toSize ada
            if (global.func && typeof global.func.toSize === 'function') {
                sizeMessage = `Size: ${await global.func.toSize(mp4[0].size)}`;
            } else {
                sizeMessage = 'Size: Unknown';
            }

            await conn.sendMessage(m.chat, {
                video: {
                    url: mp4[0].url
                },
                caption: `\`${title}\`\nQuality: ${mp4[0].quality}\n${sizeMessage}`
            }, {
                quoted: m
            });
        } else {
            await conn.sendFile(m.chat, medias[1].url, '', `\`${title}\``, m);
        }

    } catch (e) {
        throw e;
    }
};

handler.help = ['pindownload *<url>*', 'pindl *<url>*'];
handler.command = /^(pind(own)?l(oad)?)$/i;
handler.tags = ["downloader"];
handler.limit = true;

module.exports = handler;

async function pindl(url) {
    try {
        const urls = 'https://pinterestdownloader.io/frontendService/DownloaderService';
        const params = {
            url
        };

        let { data } = await axios.get(urls, { params });
        return data;
    } catch (e) {
        return { msg: e };
    }
}