let handler = (m) => m;

// Default limit cost jika handler.limit = true
const DEFAULT_LIMIT_COST = 1;

// Daftar default limit untuk command yang tidak memiliki handler.limit
const limitedCommands = {
  'ai': 5,
  // ... command lainnya
};

handler.before = async function (m) {
  try {
    if (!m.isCommand) return; // Skip jika bukan command
    
    let user = global.db.data.users[m.sender];
    if (!user) return; // Skip jika user tidak ada di database
    
    // Skip untuk user premium
    if (user.premium) return;
    
    // Dapatkan command name dari pesan
    let cmdName = m.command.toLowerCase();
    
    // Coba dapatkan plugin handler untuk command ini
    let plugin = global.plugins.get(cmdName) || global.plugins.find((v) => v.aliases && v.aliases.includes(cmdName));
    
    // Tentukan biaya limit
    let limitCost;
    
    if (plugin) {
      if (plugin.limit === true) {
        // Jika handler.limit = true, gunakan default cost
        limitCost = DEFAULT_LIMIT_COST;
      } else if (typeof plugin.limit === 'number') {
        // Jika handler.limit adalah angka, gunakan nilai tersebut
        limitCost = plugin.limit;
      }
    }
    
    // Jika tidak ada limit di handler, cek di limitedCommands
    if (!limitCost && limitedCommands.hasOwnProperty(cmdName)) {
      limitCost = limitedCommands[cmdName];
    }
    
    // Jika tidak ada limit requirement, skip
    if (!limitCost) return;
    
    // Cek apakah user memiliki cukup limit
    if (user.limit < limitCost) {
      await conn.reply(
        m.chat,
        `❌ *Limit Tidak Cukup*\n` +
        `○ Command: ${cmdName}\n` +
        `○ Limit yang dibutuhkan: ${limitCost}\n` +
        `○ Limit Anda saat ini: ${user.limit}\n\n` +
        `Gunakan *.buylimit* untuk membeli limit tambahan\n` +
        `atau *.premium* untuk menikmati limit unlimited.`,
        m
      );
      return false; // Batalkan command
    }
    
    // Kurangi limit user
    user.limit -= limitCost;
    
    // Kirim notifikasi penggunaan limit
    await conn.reply(
      m.chat,
      `*Penggunaan Limit*\n` +
      `○ Command: ${cmdName}\n` +
      `○ Limit terpakai: ${limitCost}\n` +
      `○ Sisa limit: ${user.limit}\n` +
      (user.limit < 10 ? `\n⚠️ *Peringatan:* Limit Anda hampir habis!` : ''),
      m
    );
    
    // Logging untuk monitoring
    console.log(`[LIMIT] User ${m.sender} menggunakan ${limitCost} limit untuk command ${cmdName}. Sisa: ${user.limit}`);
    
  } catch (error) {
    console.error('Error in limit detection:', error);
  }
};

module.exports = handler;