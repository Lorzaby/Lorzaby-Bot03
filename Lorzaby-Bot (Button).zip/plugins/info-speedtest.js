let cp = require('child_process')
let { promisify } = require('util')
let exec = promisify(cp.exec).bind(cp)
let handler = async (m, { conn }) => {
    await conn.reply(m.chat, '🔎 Loading...', m)
    let o
    try {
        o = await exec('python3 speed.py --share --secure')
    } catch (e) {
        o = e
    } finally {
        let { stdout, stderr } = o
        if (stdout.trim()) {
            // Mencari URL gambar dari stdout
            let url = stdout.match(/http[^\s]+/) // Regex sederhana untuk menemukan URL
            let resultText = stdout // Simpan hasil teks tes
                .replace(url, '') // Hapus URL dari hasil teks
                .replace('Share results:', '') // Hapus kalimat "Share results:"
                .replace(/\.{2,}/g, '') // Hapus titik-titik berlebih
                .trim() // Hilangkan spasi berlebih

            await conn.sendMessage(m.chat, {
                text: `${resultText}`, // Kirim teks hasil tes
                contextInfo: {
                    externalAdReply: {
                        title: "Hasil Speedtest",
                        body: "Klik untuk melihat hasil detail",
                        thumbnailUrl: url ? url[0] : "https://cdn.jsdelivr.net/gh/SazumiVicky/Storage@main/IMG_20230430_192107_543.jpg", // Jika URL ditemukan, gunakan sebagai thumbnail
                        sourceUrl: url ? url[0] : "", // URL gambar sebagai sumber
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            })
        }
        if (stderr.trim()) m.reply(stderr)
    }
}
handler.help = ['speedtest']
handler.tags = ['info']
handler.command = /^(speedtest|ookla)$/i
handler.premium = false
module.exports = handler