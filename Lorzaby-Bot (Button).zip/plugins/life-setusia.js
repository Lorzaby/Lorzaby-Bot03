var handler = async (m, {
  conn,
  text,
  usedPrefix,
  command
}) => {
  if (!text) {
    return m.reply(`Masukan jumlah usia!\n\n*Contoh:* ${usedPrefix + command} 18`)
  }
  var user = global.db.data.users[m.sender]
  var age = parseInt(text)

  if (age <= 70) {
    user.age = age
    m.reply(`Sukses mengganti usia ke *${age}*`)
  } else {
    m.reply(`Umur maksimal *70 tahun*`)
  }
}

handler.command = handler.help = ["setusia"]
handler.tags = ["life"]

module.exports = handler