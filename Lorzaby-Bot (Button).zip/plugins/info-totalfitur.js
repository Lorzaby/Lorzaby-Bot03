let handler = async (m, { conn }) => {
  try {
    const features = Object.values(global.plugins)
      .flatMap(p => p.help ? p.help : [])
      .filter(feature => feature != undefined && feature.trim() !== '');

    const totalCommands = features.length;

    await conn.reply(m.chat, `*Total fitur*: ${totalCommands} Commands`, m);
  } catch (error) {
    console.error(error);
    await conn.reply(m.chat, 'Terjadi kesalahan dalam mengeksekusi perintah.', m);
  }
}

handler.help = ['totalfitur']
handler.tags = ['main', 'info']
handler.command = /^(fitur|totalfitur)$/i
module.exports = handler;