let { MessageType } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, text }) => {
    if (conn.user.jid !== global.conn.user.jid) return;
    if (!text) return conn.reply(m.chat, '*Example:* .addmods 6285381310740', m);
    
    let who;
    if (m.isGroup) {
        who = m.mentionedJid && m.mentionedJid[0];
        if (!who) return conn.reply(m.chat, 'Harap masukan nomor penggguna yang akan ditambah sebagai Moderator.', m);
    } else {
        who = m.chat;
    }

    if (global.mods.includes(who.split('@')[0])) {
        return conn.reply(m.chat, `@${who.split('@')[0]} Sudah menjadi Moderator`, m);
    }
    
    global.mods.push(`${who.split('@')[0]}`);
    conn.reply(m.chat, `@${who.split('@')[0]} Sekarang kamu adalah seorang Moderator! Tolong jangan salah gunakan kekuasaan kamu.`, m, {
        contextInfo: {
            mentionedJid: [who]
        }
    });
}

handler.help = ['addmods *<@user>*'];
handler.tags = ['owner'];
handler.command = /^(add|tambah|\+)mods$/i;
handler.rowner = true;

module.exports = handler;