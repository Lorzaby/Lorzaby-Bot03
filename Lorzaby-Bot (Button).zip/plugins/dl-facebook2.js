let axios = require('axios')
let btchDownloader = require('btch-downloader')

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Example:* ${usedPrefix+command} *<url>*`
  try { 
    m.reply("📩 Loading...")
    let start = new Date()
    
    // Coba menggunakan btch-downloader terlebih dahulu
    let res = await downloadWithBtch(text)
    
    // Jika btch-downloader gagal, gunakan alternatif API
    if (!res) {
      res = await facebook(text)
      if(res.error) {
        throw res.error.message;
      }
    }
    
    let teks = `𝙁𝙖𝙘𝙚𝙗𝙤𝙤𝙠 𝘿𝙤𝙬𝙣𝙡𝙤𝙖𝙙𝙚𝙧\n\n`
    teks += `𝘿𝙪𝙧𝙖𝙩𝙞𝙤𝙣: ${res.duration || 'N/A'}\n`
    teks += `𝙁𝙚𝙩𝙘𝙝: ${new Date() - start} ms\n\n${set.footer}`
    conn.sendFile(m.chat, res.links.sd || res.url, '', teks, m)
  } catch (e) {
    console.log(e)
    return m.reply('Error: ' + e)
  }
}
handler.help = ["facebook2 *<url>*","fb2 *<url>*"]
handler.tags = ["downloader"]
handler.command = ["fb2","facebook2"]
handler.limit = true;
module.exports = handler

// Fungsi untuk download dengan btch-downloader
async function downloadWithBtch(url) {
  try {
    let info = await btchDownloader.facebook(url)
    return {
      duration: info.duration,
      links: {
        sd: info.url
      }
    }
  } catch (err) {
    console.log('Error using btch-downloader:', err)
    return null  // Kembali ke null jika terjadi error untuk memicu alternatif
  }
}

// Fungsi untuk download dengan API yt1s.io (alternatif)
async function facebook(url) {
  let { data } = await axios({ 
    method: 'POST', 
    url: 'https://yt1s.io/api/ajaxSearch/facebook', 
    data: `q=${encodeURIComponent(url)}&vt=facebook` 
  });
  return data;
}