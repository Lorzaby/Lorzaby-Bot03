const fs = require('fs');
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

const handler = async (m, { conn }) => {
  let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
  let payText = `Terima kasih atas donasi anda, kami sangat berterima kasih atas dukungan anda dan donasi Anda sangat berarti bagi kami.`;

  // Persiapan media gambar
  const media = await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/5c199dc98973813c32fbb.jpg' } }, { upload: conn.waUploadToServer });

  let msg = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: '120363315397973229@newsletter',
              newsletterName: 'Powered By Lorzaby',
              serverMessageId: -1
            },
            businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
            externalAdReply: {
              title: 'ʟᴏʀᴢᴀʙʏ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ',
              thumbnailUrl: 'https://telegra.ph/file/32e3b521faee1d02251b6.jpg',
              sourceUrl: 'https://bento.me/lorzaby',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: payText
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'Donate dengan nomor klik di bawah'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `*Hello, @${m.sender.replace(/@.+/g, '')}!*`,
            subtitle: "ʟᴏʀᴢᴀʙʏ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ",
            hasMediaAttachment: true,
            ...media
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: `{\"display_text\":\"Nomor Dana\",\"id\":\"123456789\",\"copy_code\":\"628881362557\"}`
              }
            ]
          })
        })
      }
    }
  }), { userJid: m.chat, quoted: m });

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
}

handler.command = /^(donasi|donate)$/i;
handler.tags = ['info'];
handler.help = ['donasi', 'donate'];

module.exports = handler;