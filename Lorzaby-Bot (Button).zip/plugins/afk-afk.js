let handler = async (m, { text }) => {
  let user = global.db.data.users[m.sender]
  user.afk = +new Date
  user.afkReason = text || '*tanpa alasan*'
  
  // Kirim pesan dengan gambar dan button
  await conn.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/jjm2jj.jpg' },
    caption: `- *Kamu sekarang AFK*\n- *Karena:* ${user.afkReason}`,
    footer: "Lorzaby WhatsApp Bot",
    buttons: [
      {
        buttonId: ".get https://files.catbox.moe/k00b09.jpg",
        buttonText: { 
          displayText: "Bye" 
        }
      },
      {
        buttonId: ".afk Ikutan AFK",
        buttonText: {
          displayText: "Ikutan"
        }
      }
    ],
    mentions: [m.sender], // Untuk memastikan tag/mention berfungsi
    viewOnce: true,
    headerType: 5
  }, { quoted: m })
}

// Handler untuk respons button
handler.buttoncmd = {
  afkwarn: async (m) => {
    conn.reply(m.chat, "Mohon jangan mengganggu user yang sedang AFK!", m)
  },
  afkbye: async (m) => {
    conn.reply(m.chat, "Sampai jumpa kembali!", m)
  }
}

handler.help = ['afk *<reason>*']
handler.tags = ['tools']
handler.command = /^afk$/i
handler.limit = false;

module.exports = handler