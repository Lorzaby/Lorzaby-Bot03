const axios = require("axios");

let handler = async (m, { conn, text }) => {
  if (!text) throw `*Example:* .ytmp32 *<url>*`;
  m.reply('📩 Loading...');
  try {
    // Mengambil data dari API
    let { data } = await axios.get(`https://api.betabotz.eu.org/api/download/ytmp3?url=${text}&apikey=${global.btc}`);

    // Menyusun pesan dengan audio, judul, dan thumbnail
    let messageOptions = {
      audio: { 
        url: data.result.mp3 
      }, // Mengirim sebagai audio WhatsApp
      mimetype: "audio/mpeg",
      ptt: false, // Menonaktifkan pengiriman sebagai pesan suara (PTT)
      caption: `*${data.result.title}*\n\nDurasi: ${data.result.duration}`, // Menambahkan judul dan durasi
      fileName: `${data.result.title}.mp3`, // Nama file audio
      thumbnail: { url: data.result.thumb }, // Menambahkan thumbnail dari YouTube
      contextInfo: {
        externalAdReply: {
          title: data.result.title, // Judul yang muncul
          body: 'YouTube Audio', // Deskripsi atau teks tambahan
          mediaUrl: text, // URL asli YouTube
          mediaType: 2, // Tipe media: video/audio
          thumbnailUrl: data.result.thumb, // URL thumbnail dari YouTube
          sourceUrl: text // URL YouTube untuk diklik pengguna
        }
      }
    };

    // Mengirim pesan dengan audio
    await conn.sendMessage(m.chat, messageOptions, { quoted: m });
  } catch (e) {
    // Mengirim pesan error jika terjadi kesalahan
    m.reply("Error: " + e.message);
  }
};

handler.tags = ['downloader'];
handler.help = ['ytmp32 *<url>*'];
handler.command = /^(ytmp32)$/i;
handler.register = false;
handler.limit = true;

module.exports = handler;