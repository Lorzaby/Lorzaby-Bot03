let handler = async (m, { conn, command, text, usedPrefix }) => {
    if (!text) throw `*Example:* ${usedPrefix + command} 😈`;
    let codePoint = Array.from(text)[0]?.codePointAt(0)?.toString(16);
    let result = codePoint
      ? `https://fonts.gstatic.com/s/e/notoemoji/latest/${codePoint}/512.webp`
      : false;
    if (!result) throw "Emoji tidak ditemukan!";
    
    // Mengirim gambar WebP sebagai stiker di WhatsApp
    await conn.sendFile(m.chat, result, '', wm, m, null, { asSticker: true });
}

handler.command = handler.help = ['emoji'];
handler.tags = ['sticker'];
handler.limit = true;

module.exports = handler;

async function NotoEmoji(emoji) {
  try {
    const codePoint = Array.from(query)[0]?.codePointAt(0)?.toString(16);
    return codePoint
      ? `https://fonts.gstatic.com/s/e/notoemoji/latest/${codePoint}/512.webp`
      : null;
  } catch (error) {
    return console.error("*Error:*", error), null;
  }
}