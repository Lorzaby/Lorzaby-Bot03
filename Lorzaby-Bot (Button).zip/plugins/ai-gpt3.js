const axios = require('axios');

async function askGpt3(prompt) {
  try {
    const messages = [
      { role: "system", content: "Saya adalah Lorzaby Bot Assisten virtual berbasis AI" },
      { role: "user", content: prompt }
    ];

    const response = await axios.post(
      "https://api.yanzbotz.live/api/ai/gpt3",
      { messages },
      {
        headers: {
          Accept: "text/event-stream",
          "Content-Type": "application/json",
        },
      }
    );

    // Ambil hanya bagian result dari respons API
    return response.data.result || 'Tidak ada hasil yang ditemukan.';
  } catch (error) {
    console.error(error);
    throw 'Maaf, terjadi kesalahan saat memproses permintaan Anda.';
  }
}

let handler = async (m, { conn, text, usedPrefix, command, args }) => {
  if (args.length >= 1) {
    text = args.slice(0).join(" ");
  } else if (m.quoted && m.quoted.text) {
    text = m.quoted.text;
  } else {
    throw "Hallo, ada yang bisa saya bantu?";
  }

  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

  try {
    const response = await askGpt3(text);
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
    
    // Kirim hasil yang sudah diproses
    await conn.reply(m.chat, response, m);
  } catch (e) {
    await conn.reply(m.chat, e, m);
  }
}

handler.help = ["gpt3 *<text>*"];
handler.tags = ["ai"];
handler.command = ["gpt3", "chatgpt3"];
handler.premium = false;
handler.limit = true;

module.exports = handler;