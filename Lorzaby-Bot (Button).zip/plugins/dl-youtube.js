const axios = require('axios');

const SaveTube = {
    qualities: {
        audio: { 1: '32', 2: '64', 3: '128', 4: '192' },
        video: { 1: '144', 2: '240', 3: '360', 4: '480', 5: '720', 6: '1080', 7: '1440', 8: '2160' }
    },
    
    headers: {
        'accept': '*/*',
        'referer': 'https://ytshorts.savetube.me/',
        'origin': 'https://ytshorts.savetube.me/',
        'user-agent': 'Postify/1.0.0',
        'Content-Type': 'application/json'
    },
    
    cdn() {
        return Math.floor(Math.random() * 11) + 51;
    },
    
    checkQuality(type, qualityIndex) {
        if (!(qualityIndex in this.qualities[type])) {
            throw new Error(`Kualitas ${type} tidak valid. Pilih salah satu: ${Object.keys(this.qualities[type]).join(', ')}`);
        }
    },
    
    async fetchData(url, cdn, body = {}) {
        const headers = {
            ...this.headers,
            'authority': `cdn${cdn}.savetube.su`
        };

        try {
            const response = await axios.post(url, body, { headers });
            return response.data;
        } catch (error) {
            console.error(error);
            throw error;
        }
    },
    
    dLink(cdnUrl, type, quality, videoKey) {
        return `https://${cdnUrl}/download`;
    },
    
    async dl(link, qualityIndex, typeIndex) {
        const type = typeIndex === 1 ? 'audio' : 'video';
        const quality = this.qualities[type][qualityIndex];
        if (!type) throw new Error('Tipe tidak valid. Pilih 1 untuk audio atau 2 untuk video.');
        this.checkQuality(type, qualityIndex);
        const cdnNumber = this.cdn();
        const cdnUrl = `cdn${cdnNumber}.savetube.su`;
        
        const videoInfo = await this.fetchData(`https://${cdnUrl}/info`, cdnNumber, { url: link });
        const badi = {
            downloadType: type,
            quality: quality,
            key: videoInfo.data.key
        };

        const dlRes = await this.fetchData(this.dLink(cdnUrl, type, quality, videoInfo.data.key), cdnNumber, badi);

        return {
            link: dlRes.data.downloadUrl,
            duration: videoInfo.data.duration,
            durationLabel: videoInfo.data.durationLabel,
            fromCache: videoInfo.data.fromCache,
            id: videoInfo.data.id,
            key: videoInfo.data.key,
            thumbnail: videoInfo.data.thumbnail,
            thumbnail_formats: videoInfo.data.thumbnail_formats,
            title: videoInfo.data.title,
            titleSlug: videoInfo.data.titleSlug,
            videoUrl: videoInfo.data.url,
            quality,
            type
        };
    }
};

async function handler(m, { conn, args, usedPrefix, command }) {
    if (!args[0]) throw `*Masukkan URL YouTube yang valid*\n\n*Contoh:*\n${usedPrefix + command} https://youtu.be/XXXXX 2 3\n\n*1 = Audio*\n*2 = Video*\n\n*Kualitas Audio:*\n1 = 32kbps\n2 = 64kbps\n3 = 128kbps\n4 = 192kbps\n\n*Kualitas Video:*\n1 = 144p\n2 = 240p\n3 = 360p\n4 = 480p\n5 = 720p\n6 = 1080p\n7 = 1440p\n8 = 2160p`;
    
    if (!args[1]) throw '*Masukkan tipe (1 = Audio, 2 = Video)*';
    if (!args[2]) throw '*Masukkan kualitas yang diinginkan*';
    
    try {
        m.reply('*📩 Sedang memproses...*');
        
        const result = await SaveTube.dl(args[0], args[2], parseInt(args[1]));
        
        const typeLabel = args[1] === '1' ? 'Audio' : 'Video';
        const qualityLabel = args[1] === '1' ? 
            `${SaveTube.qualities.audio[args[2]]}kbps` : 
            `${SaveTube.qualities.video[args[2]]}p`;
        
        const caption = `
*YouTube ${typeLabel} Downloader*

- *Judul:* ${result.title}
- *Durasi:* ${result.durationLabel}
- *Kualitas:* ${qualityLabel}
- *URL:* ${args[0]}
        `.trim();
        
        const fileName = `${result.titleSlug}.${args[1] === '1' ? 'mp3' : 'mp4'}`;
        
        if (args[1] === '1') {
            // Audio - Kirim sebagai pesan audio biasa
            await conn.sendMessage(m.chat, { 
                audio: { url: result.link },
                mimetype: 'audio/mp4',
                fileName: fileName,
                caption: caption
            }, { quoted: m });
        } else {
            // Video
            await conn.sendFile(
                m.chat,
                result.link,
                fileName,
                caption,
                m,
                true,
                {
                    type: 'videoMessage',
                    thumbnail: result.thumbnail
                }
            );
        }
    } catch (error) {
        console.error(error);
        throw `*Terjadi kesalahan:* ${error.message}`;
    }
}

handler.help = ['yt <url> <type> <quality>'];
handler.tags = ['downloader'];
handler.command = /^(yt)$/i;
handler.limit = 5
handler.premium = false;

module.exports = handler;