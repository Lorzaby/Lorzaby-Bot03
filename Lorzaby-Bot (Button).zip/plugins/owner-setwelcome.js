let handler = async (m, { conn, text, isROwner, isOwner, isAdmin, usedPrefix, command }) => {
  if (text) {
    global.db.data.chats[m.chat].sWelcome = text
    m.reply('Welcome berhasil diatur\n@user (Mention)\n@subject (Judul Group)\n@desc (Deskripsi Grup)')
  } else throw `Teksnya mana?\n\n*Example:*\n${usedPrefix + command} Hallo, @user!\nSelamat datang di group @subject\n\n@desc`
}
handler.help = ['setwelcome *<text>*']
handler.tags = ['group']
handler.command = /^(setwelcome)$/i
handler.group = true
handler.owner = true

module.exports = handler
