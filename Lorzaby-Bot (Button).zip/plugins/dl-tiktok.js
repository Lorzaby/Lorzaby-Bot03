const axios = require('axios');

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
  if (!text) return m.reply(`*Cara Penggunaan:*\n${usedPrefix + command} search query\n${usedPrefix + command} URL\n${usedPrefix + command} stalk username`);
  
  // Cek jika input adalah URL
  const isUrl = (url) => {
    try {
      new URL(url);
      return url.includes('tiktok.com');
    } catch {
      return false;
    }
  };

  let [action, ...query] = text.split(' ');
  query = query.join(' ');
  
  // Jika input adalah URL, langsung jalankan fungsi download
  if (isUrl(action)) {
    query = action;
    action = 'download';
  }
  
  const Tiktok = {
    search: async(q) => {
      const maxRetries = 10;
      let attempt = 0; 
      let response;
      while (attempt < maxRetries) {
        try {
          const data = {
            count: 20,
            cursor: 0,
            web: 1,
            hd: 1,
            keywords: q,
          };
          const config = {
            method: "post",
            url: "https://tikwm.com/api/feed/search",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
              Accept: "application/json, text/javascript, */*; q=0.01",
              "X-Requested-With": "XMLHttpRequest",
              "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
              Referer: "https://tikwm.com/",
            },
            data: data,
          };
          response = await axios(config);
          if (response.data.data) {
            return response.data.data.videos.map((a) => ({
              title: a.title,
              duration: a.duration,
              play: "https://tikwm.com" + a.play,
              stats: {
                play: Number(a.play_count).toLocaleString(),
                like: Number(a.digg_count).toLocaleString(),
                comment: Number(a.comment_count).toLocaleString(),
                share: Number(a.share_count).toLocaleString()
              },
              author: {
                name: a.author.nickname,
                username: "@" + a.author.unique_id
              }
            }));
          } else {
            attempt++;
            await new Promise(resolve => setTimeout(resolve, 2000)); 
          }
        } catch (error) {
          attempt++;
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }
      return "Terlalu banyak request, mohon tunggu sebentar...";
    },
    download: async(url) => {
      return new Promise(async (resolve, reject) => {
        try {
          const encodedParams = new URLSearchParams();
          encodedParams.set("url", url);
          encodedParams.set("hd", "1");

          const response = await axios({
            method: "POST",
            url: "https://tikwm.com/api/",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
              Cookie: "current_language=en",
              "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            data: encodedParams,
          });
          resolve(response.data.data);
        } catch (error) {
          reject(error);
        }
      });
    },
    stalk: async function(nickname) {
      return new Promise(async(resolve, reject) => {
        const headers = {
          "Referer": 'https://countik.com/user/@' + nickname,
          "User-Agent": require("fake-useragent")()
        }
        await axios.get(`https://countik.com/api/exist/${nickname.toLowerCase()}`, { headers })
          .then(async(a) => {
            let id = a.data.sec_uid
            if (!id) reject({
              msg: "ID tidak ditemukan!"
            })
            let { data } = await axios.get(`https://countik.com/api/userinfo?sec_user_id=${id}`, { headers }).catch(e => e.response);
            if (!data.followerCount) return reject({
              msg: "Username Tiktok tidak ditemukan!"
            })
            resolve({
              nickname: a.data.nickname,
              avatar: data.avatarThumb,
              country: data.country,
              followers: data.followerCount.toLocaleString(),
              following: data.followingCount.toLocaleString(),
              bio: data.signature,
              heart: data.heartCount.toLocaleString()
            })
          }).catch((e) => reject({ msg: "Gagal mendapatkan data dari Web", error: e.response.data }))
      })
    }
  };

  try {
    await conn.sendMessage(m.chat, { react: { text: "📩", key: m.key }});
    
    switch (action.toLowerCase()) {
      case 'search': {
        if (!query) return m.reply('Masukkan kata kunci pencarian!');
        const results = await Tiktok.search(query);
        
        if (typeof results === 'string') return m.reply(results);
        
        for (let i = 0; i < Math.min(results.length, 5); i++) {
          const video = results[i];
          const caption = `*TIKTOK SEARCH*\n\n` +
            `📝 *Judul:* ${video.title}\n` +
            `👤 *Author:* ${video.author.name} (${video.author.username})\n` +
            `⌚ *Durasi:* ${video.duration}s\n` +
            `📊 *Statistik:*\n` +
            `▸ Views: ${video.stats.play}\n` +
            `▸ Likes: ${video.stats.like}\n` +
            `▸ Comments: ${video.stats.comment}\n` +
            `▸ Share: ${video.stats.share}`;

          await conn.sendFile(m.chat, video.play, "tiktok.mp4", caption, m);
        }
        break;
      }
      
      case 'download': {
        if (!query) return m.reply('Masukkan URL TikTok!');
        const result = await Tiktok.download(query);
        
        const caption = `*TIKTOK DOWNLOADER*\n\n` +
          `📝 *Title:* ${result.title}\n` +
          `👤 *Author:* ${result.author.nickname}\n` +
          `⌚ *Duration:* ${result.duration}s\n` +
          `❤️ *Likes:* ${result.digg_count}\n` +
          `💬 *Comments:* ${result.comment_count}\n` +
          `🔄 *Shares:* ${result.share_count}\n`;

        if (result.images) {
          for (let img of result.images) {
            await conn.sendFile(m.chat, img, "", caption, m);
          }
          
          await conn.sendMessage(m.chat, { 
            audio: { 
              url: result.music 
            },
            mimetype: 'audio/mpeg',
            ptt: false,
            contextInfo: {
              externalAdReply: {
                title: result.music_info.title,
                body: result.music_info.author || '',
                thumbnailUrl: result.music_info.cover,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          }, { quoted: m });
        } else {
          await conn.sendFile(m.chat, result.play, "tiktok.mp4", caption, m);
          
          await conn.sendMessage(m.chat, { 
            audio: { 
              url: result.music 
            },
            mimetype: 'audio/mpeg',
            ptt: false,
            contextInfo: {
              externalAdReply: {
                title: result.music_info.title,
                body: result.music_info.author || '',
                thumbnailUrl: result.music_info.cover,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          }, { quoted: m });
        }
        break;
      }
      
      case 'stalk': {
        if (!query) return m.reply('Masukkan username TikTok!');
        const user = await Tiktok.stalk(query);
        const caption = `*TIKTOK STALK*\n\n` +
          `👤 *Nickname:* ${user.nickname}\n` +
          `🌍 *Country:* ${user.country}\n` +
          `✍️ *Bio:* ${user.bio}\n` +
          `👥 *Followers:* ${user.followers}\n` +
          `👣 *Following:* ${user.following}\n` +
          `❤️ *Hearts:* ${user.heart}`;
          
        await conn.sendFile(m.chat, user.avatar, null, caption, m);
        break;
      }
      
      default:
        return m.reply(`*Command tidak valid!*\n\nGunakan:\n${usedPrefix + command} search query\n> Untuk searching\n${usedPrefix + command} URL\n> Untuk Download\n${usedPrefix + command} stalk username\n> Untuk stalking`);
    }
    
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key }});
    throw `*Error:* ${e}`;
  }
};

handler.help = ['tiktok *<search/URL/stalk>*'];
handler.tags = ['downloader', 'search'];
handler.command = /^(tiktok|tt)$/i;
handler.limit = true;

module.exports = handler;