const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*Example:* .ytmp42 *<url>*`;

    if (!text) throw 'Masukan Link YouTube';
    m.reply(wait);
    const response = await axios.get(`https://api.betabotz.eu.org/api/download/ytmp4?url=${text}&apikey=${global.btc}`);
    const res = response.data.result;
    var { mp4, id, title, source, duration } = res;
    let capt = `𝙔𝙊𝙐𝙏𝙐𝘽𝙀 𝙑𝙄𝘿𝙀𝙊 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿𝙀𝙍`;

    // Mengirim video sebagai MP4
    await conn.sendMessage(m.chat, { 
        video: { url: mp4 },
        mimetype: 'video/mp4',
        fileName: `${title}.mp4`,
        caption: capt
    }, { quoted: m });
};

handler.help = ['ytmp42 *<url>*'];
handler.command = /^(ytmp42)$/i
handler.tags = ['downloader'];
handler.limit = true;
handler.fail = null;

module.exports = handler;