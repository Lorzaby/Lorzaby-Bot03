const { twitter } = require('btch-downloader')
const fetch = require("node-fetch");

const handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    if (!args[0]) throw `*Example:* ${usedPrefix+command} *<url>*`;
    if (!args[0].match(/https?:\/\/(www\.)?(twitter\.com|x\.com)/gi)) throw "URL Tidak Ditemukan!";
    m.reply(wait);
    try {
        const api = await fetch(`https://api.betabotz.eu.org/api/download/twitter2?url=${args[0]}&apikey=${global.btc}`);
        const res = await api.json();
        const mediaURLs = res.result.mediaURLs;
        
        const capt = `𝙐𝙨𝙚𝙧𝙣𝙖𝙢𝙚: ${res.result.user_name} ${res.result.user_screen_name}\n𝙏𝙞𝙩𝙡𝙚: ${res.result.text}\n𝙍𝙚𝙥𝙡𝙞𝙚𝙨: ${res.result.replies}\n𝙍𝙚𝙩𝙬𝙚𝙚𝙩: ${res.result.retweets}`;
        
        for (const url of mediaURLs) {
            const response = await fetch(url);
            const buffer = await response.buffer();  
            await delay(3000)//3 detik jeda agar tidak spam        
            conn.sendFile(m.chat, buffer, null, capt, m);           
        }
    } catch (e) {
        throw '𝙏𝙚𝙧𝙟𝙖𝙙𝙞 𝙀𝙧𝙧𝙤𝙧!';
    }
};

handler.help = ["twitter *<url>*","twt *<url>*"];
handler.tags = ["downloader"];
handler.command = ["twitter","twt"];
handler.limit = true;
handler.fail = null;

module.exports = handler;

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
	}