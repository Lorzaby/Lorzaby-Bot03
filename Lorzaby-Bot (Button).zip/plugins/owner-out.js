const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

let handler = async (m, { conn, args, command, usedPrefix, text, participants }) => {
    
    if (!conn.cacheIdGc) conn.cacheIdGc = [];

    let botGroups = Object.keys(conn.chats)
        .filter(key => key.endsWith('@g.us'))
        .map(key => conn.chats[key].id);

    var groups = Object.keys(conn.chats)
        .filter(key => key.endsWith('@g.us'))
        .map(key => conn.chats[key])
        .filter(group => !conn.cacheIdGc.includes(group.id)); 

    if (args.length === 0) {
        let sections = [{
            title: 'Daftar Grup',
            rows: groups.map((group, index) => ({
                title: group.subject,
                description: `Pilih untuk keluar dari ${group.subject}`,
                id: `${usedPrefix}out ${index + 1}`
            }))
        }];

        let listMessage = {
            title: 'Click Disini',
            sections
        };

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            mentionedJid: [m.sender]
                        },
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: 'Silahkan pilih grup dari daftar untuk melakukan tindakan.'
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: 'Lorzaby WhatsApp Bot'
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: `*Hai @${m.sender.replace(/@.+/g, '')}*`,
                            subtitle: "Lorzaby",
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "single_select",
                                    "buttonParamsJson": JSON.stringify(listMessage)
                                }
                            ],
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });
        conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } else if (args.length === 1 && /^\d+$/.test(args[0])) {
        var index = parseInt(args[0]) - 1;
        if (index >= 0 && index < groups.length) {
            var group = groups[index];
            var capt = `*Masa Sewa Bot Telah Habis!*\n\n"Terimakasih telah menggunakan layanan Lorzaby WhatsApp Bot! Kami mohon maaf atas kendala atau bug yang mungkin sering terjadi selama menggunakan bot. Bot akan otomatis keluar dari grup ini. Terima kasih atas dukungan dan pengertiannya, sampai jumpa di kesempatan berikutnya.`;

            let kemii = await conn.sendMessage(group.id, { text: capt, mentions: participants.map(a => a.id) });
            await conn.groupLeave(group.id);

            if (!conn.cacheIdGc.includes(group.id)) {
                conn.cacheIdGc.push(group.id);
            }

            await conn.reply(m.chat, `Bot berhasil keluar dari grup yang dipilih!`, m);
        } else {
            conn.reply(m.chat, 'Grup dengan urutan tersebut tidak ditemukan.', m);
        }
    } else {
        conn.reply(m.chat, `*Gunakan:* ${usedPrefix}out <id>`, m);
    }
};

handler.help = ['out'];
handler.tags = ['owner'];
handler.command = /^(out)$/i;

handler.owner = true;

module.exports = handler;