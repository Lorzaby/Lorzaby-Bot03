let handler = async (m, { conn, usedPrefix }) => {
let text = `
"Script ini adalah script asli milik Kemii yang telah di-recode dan disesuaikan oleh Lorzaby untuk keperluan pengembangan lebih lanjut."

*Requirement :*
• NodeJS V18
• FFMPEG
• IMAGEMAGICK
• Ram Minimal 5GB
`
conn.sendFile(m.chat, 'https://files.catbox.moe/by4b2w.png', '', text, m)
}
handler.help = ['sc', 'sourcecode']
handler.tags = ['info']
handler.command = /^(sc|sourcecode)$/i
handler.register = false

module.exports = handler