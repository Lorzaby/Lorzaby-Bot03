let handler = async (m, { isPrems, conn, text, usedPrefix, command }) => {
  let user = global.db.data.users[m.sender]

  if (!/^[a-zA-Z\s]+$/.test(text)) {
    m.reply('*Example:* .setkota jakarta');
    return;
  }

  if (!text || text.length < 3 || text.length > 40) {
    m.reply('Mohon masukkan nama kota yang kamu inginkan dengan benar! Maksimal 40 kata.');
    return;
  }

  // Set kota pengguna
  user.city = text.trim()

  await conn.reply(m.chat, `Nama kota berhasil diubah menjadi *${text.trim()}*.`, m);
};

handler.help = ['setkota']
handler.tags = ['life'];
handler.limit = false
handler.command = /^setkota$/i;

module.exports = handler