const uploadImage = require("../lib/uploadFile")
const axios = require("axios")

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command,
    text
}) => {
    if (!text) return m.reply("*Example:* .gemini selamat siang")
    await m.react('⏳')
    
    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ""
        
        const API_KEY = 'AIzaSyDdklSBv4TE2Ov61grM219ZI6gbUkr0RJY'
        const BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models'
        
        const axiosConfig = {
            headers: {
                'Content-Type': 'application/json'
            },
            params: {
                key: API_KEY
            }
        }
        
        let response
        
        if (!mime) {
            // Query teks menggunakan gemini-1.5-pro
            const { data } = await axios.post(`${BASE_URL}/gemini-1.5-pro:generateContent`, {
                contents: [{
                    parts: [{
                        text: text
                    }]
                }]
            }, axiosConfig)
            
            response = data.candidates[0].content.parts[0].text
            
        } else {
            // Query dengan gambar menggunakan gemini-1.5-flash
            if (!/image\/(png|jpe?g)/.test(mime)) {
                return m.reply("Hanya mendukung format gambar PNG dan JPEG!")
            }
            
            const media = await q.download()
            const imageUrl = await uploadImage(media)
            const imageBuffer = await axios.get(imageUrl, { responseType: 'arraybuffer' })
            const base64Image = Buffer.from(imageBuffer.data).toString('base64')
            
            const { data } = await axios.post(`${BASE_URL}/gemini-1.5-flash:generateContent`, {
                contents: [{
                    parts: [{
                        text: text
                    }, {
                        inline_data: {
                            mime_type: mime,
                            data: base64Image
                        }
                    }]
                }]
            }, axiosConfig)
            
            response = data.candidates[0].content.parts[0].text
        }
        
        await conn.sendMessage(m.chat, {
            text: response,
            contextInfo: {
                externalAdReply: {
                    title: 'Artificial Intelligence Gemini',
                    thumbnailUrl: 'https://telegra.ph/file/06c03ab79eab045fcaf26.jpg',
                    sourceUrl: 'https://bento.me/lorzaby',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })
        
    } catch (error) {
        console.error('Error details:', error.response?.data || error.message)
        m.reply("Terjadi kesalahan saat memproses permintaan. Silakan coba lagi.")
    }
}

handler.help = ["gemini"].map(a => a + " *<text>*")
handler.tags = ["ai"]
handler.command = /^(gemini)$/i
handler.premium = false
handler.limit = true;
handler.register = true

module.exports = handler

/* With Library

const uploadImage = require("../lib/uploadFile");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const axios = require("axios");

// Inisialisasi Gemini AI
const genAI = new GoogleGenerativeAI('AIzaSyDdklSBv4TE2Ov61grM219ZI6gbUkr0RJY');
const modelPro = genAI.getGenerativeModel({ model: 'gemini-pro' });
const modelVision = genAI.getGenerativeModel({ model: 'gemini-pro-vision' });

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command,
    text
}) => {
    if (!text) return m.reply("*Example:* .gemini selamat siang");
    await m.react('⏳');
    
    try {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || "";
        
        let response;
        
        if (!mime) {
            // Text-only query using Gemini-Pro
            const result = await modelPro.generateContent(text);
            const responseText = await result.response.text();
            
            response = responseText;
        } else {
            // Image query using Gemini-Pro-Vision
            if (!/image\/(png|jpe?g)/.test(mime)) {
                return m.reply("Hanya mendukung format gambar PNG dan JPEG!");
            }
            
            const media = await q.download();
            const link = await uploadImage(media);
            
            // Convert image to base64
            const imageResponse = await axios.get(link, { responseType: 'arraybuffer' });
            const imageBase64 = Buffer.from(imageResponse.data).toString('base64');
            
            const imageParts = [{
                inlineData: {
                    data: imageBase64,
                    mimeType: mime
                }
            }];
            
            const result = await modelVision.generateContent([text, ...imageParts]);
            const responseText = await result.response.text();
            
            response = responseText;
        }
        
        // Kirim respons dengan format yang diminta
        await conn.sendMessage(m.chat, {
            text: response,
            contextInfo: {
                externalAdReply: {
                    title: 'Artificial Intelligence Gemini',
                    thumbnailUrl: 'https://telegra.ph/file/06c03ab79eab045fcaf26.jpg',
                    sourceUrl: 'https://bento.me/lorzaby',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
        
    } catch (error) {
        console.error('Error:', error);
        m.reply("Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi.");
    }
};

handler.help = ["gemini"].map(a => a + " *<text>*");
handler.tags = ["ai"];
handler.command = /^(gemini)$/i;
handler.premium = false;
handler.register = true;

module.exports = handler;