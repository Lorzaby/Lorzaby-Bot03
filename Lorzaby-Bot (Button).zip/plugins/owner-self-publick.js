let handler = async(m, { conn, command }) => {
  let isPublic = command === "public";
  let self = global.opts["self"]

  if(self === !isPublic) return conn.reply(m.chat, `Udah ${!isPublic ? "self" : "public"} dari tadi ${m.sender.split("@")[0] === global.owner[1] ? "kak" : "bang"} 🗿`, m)

  global.opts["self"] = !isPublic

  conn.reply(m.chat, `Berhasil ${!isPublic ? "Self" : "Public"} Bot!`, m)
}

handler.help = ["self", "public"]
handler.tags = ["owner"]
handler.rowner = true
handler.command = /^(self|public)/i

module.exports = handler