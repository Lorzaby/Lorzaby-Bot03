const axios = require('axios');

const SaveTube = {
    headers: {
        'accept': '*/*',
        'referer': 'https://ytshorts.savetube.me/',
        'origin': 'https://ytshorts.savetube.me/',
        'user-agent': 'Postify/1.0.0',
        'Content-Type': 'application/json'
    },
    
    cdn() {
        return Math.floor(Math.random() * 11) + 51;
    },
    
    async fetchData(url, cdn, body = {}) {
        const headers = {
            ...this.headers,
            'authority': `cdn${cdn}.savetube.su`
        };

        try {
            const response = await axios.post(url, body, { headers });
            return response.data;
        } catch (error) {
            console.error(error);
            throw error;
        }
    },
    
    dLink(cdnUrl, videoKey) {
        return `https://${cdnUrl}/download`;
    },
    
    async dl(link) {
        const cdnNumber = this.cdn();
        const cdnUrl = `cdn${cdnNumber}.savetube.su`;
        
        const videoInfo = await this.fetchData(`https://${cdnUrl}/info`, cdnNumber, { url: link });
        const badi = {
            downloadType: 'video',
            quality: '360',
            key: videoInfo.data.key
        };

        const dlRes = await this.fetchData(this.dLink(cdnUrl, videoInfo.data.key), cdnNumber, badi);

        return {
            link: dlRes.data.downloadUrl,
            duration: videoInfo.data.duration,
            durationLabel: videoInfo.data.durationLabel,
            thumbnail: videoInfo.data.thumbnail,
            title: videoInfo.data.title,
            titleSlug: videoInfo.data.titleSlug
        };
    }
};

async function handler(m, { conn, args, usedPrefix, command }) {
    if (!args[0]) throw `*Masukkan URL YouTube yang valid*\n\n*Contoh:*\n${usedPrefix + command} https://youtu.be/XXXXX`;
    
    try {
        m.reply('*📩 Sedang memproses video...*');
        
        const result = await SaveTube.dl(args[0]);
        
        const caption = `
*YouTube Video Downloader*

- *Judul:* ${result.title}
- *Durasi:* ${result.durationLabel}
- *Kualitas:* 360p
- *URL:* ${args[0]}
        `.trim();
        
        const fileName = `${result.titleSlug}.mp4`;
        
        await conn.sendFile(
            m.chat,
            result.link,
            fileName,
            caption,
            m,
            true,
            {
                type: 'videoMessage',
                thumbnail: result.thumbnail
            }
        );
    } catch (error) {
        console.error(error);
        throw `*Terjadi kesalahan:* ${error.message}`;
    }
}

handler.help = ['ytmp4 <url>'];
handler.tags = ['downloader'];
handler.command = /^(ytmp4)$/i;
handler.limit = 5
handler.premium = false;

module.exports = handler;