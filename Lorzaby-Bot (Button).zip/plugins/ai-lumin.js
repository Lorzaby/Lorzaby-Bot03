const axios = require('axios');
const uploadImage = require("../lib/uploadFile");

const api = axios.create({
    baseURL: 'https://luminai.my.id',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Axios-Instance/1.0'
    }
});

// Menyimpan sesi chat
const sessions = new Map();

// Fungsi untuk membersihkan sesi yang tidak aktif setelah 5 menit
function cleanupSessions() {
    const now = Date.now();
    for (const [userId, session] of sessions.entries()) {
        if (now - session.lastUpdate > 5 * 60 * 1000) { // 5 menit
            sessions.delete(userId);
        }
    }
}

// Jalankan cleanup setiap menit
setInterval(cleanupSessions, 60 * 1000);

async function handler(m, { conn, args, text, usedPrefix, command }) {
    let waitMsg;
    try {
        if (!text && command === 'lumin') {
            return m.reply(`Berikan pertanyaan!`);
        }

        // Mendapatkan nama pengguna
        let name = conn.getName(m.sender)

        // Setup waktu dan tanggal
        let d = new Date(new Date + 3600000)
        let locale = 'id'
        const jam = new Date().toLocaleString("en-US", {timeZone: "Asia/Jakarta"});
        let hari = d.toLocaleDateString(locale, { weekday: 'long' })
        let tgl = d.toLocaleDateString(locale, {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        })

        // Template prompt
        const prompt = `Kamu adalah AI Assistant LuminAI. Kamu diciptakan dan dikembangkan oleh LuminAI Incorporated. Lawan bicaramu adalah ${name}. Ekspresikan sifat mu dengan emot whatsapp. Selalu gunakan bahasa indonesia dan menggunakan kata panggilan seperti aku dan kamu dalam mengobrol. Kamu mengobrol seakan-akan seperti manusia. Waktu saat ini adalah hari ${hari}, jam ${jam}, dan tanggal ${tgl}`

        // Kirim pesan loading yang akan diedit nanti
        waitMsg = await conn.sendMessage(m.chat, { text: '...' });

        // Cek dan inisialisasi sesi jika belum ada
        if (!sessions.has(m.sender)) {
            sessions.set(m.sender, {
                lastUpdate: Date.now(),
                context: []
            });
        }

        const session = sessions.get(m.sender);
        session.lastUpdate = Date.now();

        // Deteksi command untuk generate image
        const imageGenKeywords = ['buat gambar', 'bikin gambar', 'buatin gambar', 'bikinin gambar'];
        const isImageGenRequest = imageGenKeywords.some(keyword => text.toLowerCase().startsWith(keyword));

        // Deteksi command untuk analisis gambar
        const imageAnalysisKeywords = ['analisis gambar', 'lihat gambar', 'cek gambar'];
        const isImageAnalysisRequest = imageAnalysisKeywords.some(keyword => text.toLowerCase().startsWith(keyword));

        if (command === 'lumin') {
            if (isImageGenRequest) {
    // Extract prompt gambar (hilangkan keyword dari text)
    const imagePrompt = text.replace(new RegExp(`^(${imageGenKeywords.join('|')})\\s*`, 'i'), '').trim();
    
    const imgResponse = await api.post('/', {
        content: imagePrompt,
        cName: 'ImageGenerationLV45LJp',
        cID: 'ImageGenerationLV45LJp'
    });

    const urlRegex = /https:\/\/storage\.googleapis\.com\/[^\s")]+/;
    const imageUrlMatch = urlRegex.exec(JSON.stringify(imgResponse.data.result));

    if (!imageUrlMatch) throw 'Gagal mendapatkan URL gambar';

    // Edit pesan loading alih-alih menghapusnya
    await conn.sendMessage(m.chat, { 
        text: `Berikut hasil dari "${imagePrompt}"`,
        edit: waitMsg.key 
    });
    
    // Kirim gambar
    await conn.sendFile(m.chat, imageUrlMatch[0], 'image.jpg', `*Hasil:* ${imagePrompt}`, m);

            } else if (isImageAnalysisRequest && m.quoted?.mimetype?.startsWith('image/')) {
                const image = await uploadImage(await m.quoted.download());
                
                const analysisResponse = await api.post('/', {
                    content: 'Analisis gambar ini secara detail',
                    imageBuffer: image,
                    prompt: prompt
                });

                // Edit pesan loading dengan hasil analisis
                await conn.sendMessage(m.chat, { 
                    text: analysisResponse.data.result,
                    edit: waitMsg.key 
                });

            } else {
                // Regular chat mode
                const response = await api.post('/', {
                    content: text,
                    user: m.sender,
                    prompt: prompt
                });

                // Update context
                session.context.push(text);
                session.context.push(response.data.result);

                // Batasi context untuk menghemat memori (misalnya 10 pesan terakhir)
                if (session.context.length > 10) {
                    session.context = session.context.slice(-10);
                }

                // Edit pesan loading dengan hasil chat
                await conn.sendMessage(m.chat, { 
                    text: response.data.result,
                    edit: waitMsg.key 
                });
            }
        }
    } catch (error) {
        console.error(error);
        if (waitMsg) {
            await conn.sendMessage(m.chat, { 
                text: 'Terjadi kesalahan: ' + error.message,
                edit: waitMsg.key 
            });
        } else {
            m.reply('Terjadi kesalahan: ' + error.message);
        }
    }
}

handler.help = ['lumin *<query>*'];
handler.tags = ['ai'];
handler.command = ['lumin'];
handler.premium = false;
handler.limit = 5;
handler.group = false;

module.exports = handler;