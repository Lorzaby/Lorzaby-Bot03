const { tmpdir } = require('os')
const { join } = require('path')
const { readdirSync, statSync, unlinkSync, existsSync, readFileSync, watch } = require('fs')

let handler = async (m, { args, text, conn }) => {
  // Function untuk membersihkan file temporary
  const cleanTmp = async () => {
    const tmp = [tmpdir(), join(__dirname, '../tmp')]
    const deletedFiles = []

    tmp.forEach(dirname => {
      try {
        readdirSync(dirname).forEach(file => {
          const filePath = join(dirname, file)
          try {
            const stats = statSync(filePath)
            unlinkSync(filePath)
            deletedFiles.push(filePath)
          } catch (err) {
            console.error(`Error processing file ${filePath}:`, err)
          }
        })
      } catch (err) {
        console.error(`Error reading directory ${dirname}:`, err)
      }
    })

    // Kirim notifikasi ke owner jika ada file yang dihapus
    if (deletedFiles.length > 0) {
      const ownerNumber = global.owner[0][0]
      const message = `🗑️ Auto Tmp Cleaned:\n\nDeleted ${deletedFiles.length} files:\n${deletedFiles.slice(0, 20).join('\n')}${deletedFiles.length > 20 ? `\n...and ${deletedFiles.length - 20} more files` : ''}`
      
      try {
        await conn.sendMessage(ownerNumber + '@s.whatsapp.net', {
          text: message
        })
        console.log('Tmp cleanup notification sent to owner')
      } catch (error) {
        console.log('Error sending tmp cleanup notification:', error)
      }
    }

    return deletedFiles
  }

  // Handle command manual clean
  if (m.chat) {
    const deletedFiles = await cleanTmp()
    
    if (deletedFiles.length > 0) {
      conn.reply(m.chat, `Success!\nDeleted ${deletedFiles.length} temporary files`, m)
    } else {
      conn.reply(m.chat, 'No temporary files to clean', m)
    }
  }

  // Set interval untuk auto clean setiap 5 menit
  setInterval(async () => {
    console.log('Running auto tmp cleanup...')
    await cleanTmp()
  }, 5 * 60 * 1000) // 5 menit
}

handler.help = ['clear']
handler.tags = ['owner']
handler.command = /^(clear)$/i
handler.mods = true
handler.owner = true

module.exports = handler