/* 

const axios = require('axios');

const handler = async (m, { conn }) => {
  let audio = {
    audio: { url: 'https://pomf2.lain.la/f/7ixvc40h.mp3' },
    mimetype: 'audio/mp4',
    ptt: true,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: 'Waalaikumsalam', // Assuming wm and botdate are predefined variables
        body: 'Lorzaby', // Assuming wm and botdate are predefined variables
        sourceUrl: '',
        thumbnail: (await axios.get('https://telegra.ph/file/32e3b521faee1d02251b6.jpg', { responseType: 'arraybuffer' })).data,
        renderLargerThumbnail: true
      }
    }
  };

  conn.sendMessage(m.chat, audio, { quoted: m });
};

handler.customPrefix = /^(assalam|asalam(ualaikum)?)/i;
handler.command = new RegExp();
module.exports = handler;