let fetch = require('node-fetch');
let handler = async (m, { conn, args }) => {
  let date = new Date();
  let year = date.getFullYear();
  let month = date.getMonth() + 1;
  let day = date.getDate();
  let hour = date.getHours();
  let minute = date.getMinutes();
  let second = date.getSeconds();
  
  let clockString = `*Tanggal:* ${day}/*Bulan:* ${month}/*Tahun:* ${year} - *Pukul:* ${hour}:${minute}:${second}`;
  
  // Mengirimkan hasil ke grup atau pengguna
  conn.reply(m.chat, clockString, m);
}

handler.help = ['kalender'];
handler.tags = ['info'];
handler.command = /^(kalender)$/i;

module.exports = handler;