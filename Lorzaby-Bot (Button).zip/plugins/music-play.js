const axios = require('axios');
const yts = require('yt-search');

const SaveTube = {
    headers: {
        'accept': '*/*',
        'referer': 'https://ytshorts.savetube.me/',
        'origin': 'https://ytshorts.savetube.me/',
        'user-agent': 'Postify/1.0.0',
        'Content-Type': 'application/json'
    },
    
    async fetchData(url, cdn, body = {}) {
        const headers = {
            ...this.headers,
            'authority': `cdn${cdn}.savetube.su`
        };

        try {
            const response = await axios.post(url, body, { headers });
            return response.data;
        } catch (error) {
            console.error(error);
            throw error;
        }
    },
    
    async downloadAudio(link) {
        const cdnNumber = Math.floor(Math.random() * 11) + 51;
        const cdnUrl = `cdn${cdnNumber}.savetube.su`;
        
        const videoInfo = await this.fetchData(`https://${cdnUrl}/info`, cdnNumber, { url: link });
        
        const badi = {
            downloadType: 'audio',
            quality: '128',
            key: videoInfo.data.key
        };

        const dlRes = await this.fetchData(`https://${cdnUrl}/download`, cdnNumber, badi);

        return {
            link: dlRes.data.downloadUrl,
            title: videoInfo.data.title,
            duration: videoInfo.data.durationLabel,
            thumbnail: videoInfo.data.thumbnail
        };
    }
};

async function handler(m, { conn, text, usedPrefix, command }) {
    if (!text) throw `Masukan judul lagu!`;
    
    try {
        // Menambahkan emoji reaction ⏳
    await conn.sendMessage(m.chat, { react: { text: '📩', key: m.key } });
        
        // Cari video di YouTube
        const search = await yts(text);
        if (!search.videos.length) throw 'Video tidak ditemukan';
        
        const video = search.videos[0];
        
        // Download audio
        const result = await SaveTube.downloadAudio(video.url);
        
        // Menyusun pesan dengan audio, thumbnail, dan informasi
        let messageOptions = {
            audio: {
                url: result.link
            },
            mimetype: 'audio/mpeg',
            fileName: `${result.title}.mp3`,
            contextInfo: {
                externalAdReply: {
                    title: result.title,
                    body: "",
                    thumbnailUrl: result.thumbnail,
                    sourceUrl: video.url,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: true
                }
            }
        };

        // Kirim pesan dengan format baru
        await conn.sendMessage(m.chat, messageOptions, { quoted: m });
        
    } catch (error) {
        console.error(error);
        throw `*Terjadi kesalahan:* ${error.message}`;
    }
}

handler.help = ['play <judul lagu>'];
handler.tags = ['music'];
handler.command = /^(play)$/i;
handler.limit = 5
handler.premium = false;

module.exports = handler;