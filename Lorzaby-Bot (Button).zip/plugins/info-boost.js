let { performance } = require('perf_hooks')

let handler = async (m, { conn }) => {
    // Initial message
    const msg = await conn.sendMessage(m.chat, {
        text: 'Waiting is being accelerated...'
    })

    // Loading states array
    const loadingStates = [
        '[▒▒▒▒▒▒▒▒▒▒] 0%',
        '[█▒▒▒▒▒▒▒▒▒] 10%',
        '[██▒▒▒▒▒▒▒▒] 20%',
        '[███▒▒▒▒▒▒▒] 30%',
        '[████▒▒▒▒▒▒] 40%',
        '[█████▒▒▒▒▒] 50%',
        '[██████▒▒▒▒] 60%',
        '[███████▒▒▒] 70%',
        '[████████▒▒] 80%',
        '[█████████▒] 90%',
        '[██████████] 100%'
    ]

    const delay = ms => new Promise(resolve => setTimeout(resolve, ms))
    let old = performance.now()

    // Update the message with loading animation
    for (let state of loadingStates) {
        await delay(300) // Add delay between updates
        try {
            await conn.relayMessage(m.chat, {
                protocolMessage: {
                    key: msg.key,
                    type: 14,
                    editedMessage: {
                        conversation: state
                    }
                }
            }, {})
        } catch (e) {
            console.error('Error updating message:', e)
        }
    }

    // Add some random "connection lost" effect occasionally
    if (Math.random() < 0.3) { // 30% chance
        await delay(400)
        await conn.relayMessage(m.chat, {
            protocolMessage: {
                key: msg.key,
                type: 14,
                editedMessage: {
                    conversation: '*Connection Lost...*'
                }
            }
        }, {})
        await delay(500)
    }

    let neww = performance.now()
    let speed = (neww - old).toFixed(3)

    // Final update with completion message
    await conn.relayMessage(m.chat, {
        protocolMessage: {
            key: msg.key,
            type: 14,
            editedMessage: {
                conversation: `*Bot succeeded in Accelerate!*\n*Speed:* ${speed} second!`
            }
        }
    }, {})
}

handler.help = ['boost', 'refresh']
handler.tags = ['info']
handler.command = /^boost|refresh/i
handler.rowner = true
handler.fail = null

module.exports = handler