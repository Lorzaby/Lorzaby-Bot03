let handler = async (m, { conn, usedPrefix }) => {
    let chats = Object.entries(global.db.data.chats).filter(chat => chat[1].isBanned)
    let users = Object.entries(global.db.data.users).filter(user => user[1].banned)
    let now = new Date().getTime()

    // Function to check ban status and return formatted string
    const getBanStatus = (user) => {
        if (!user.banExpiry || user.banExpiry === 0) return '*Permanen!*'
        
        if (now >= user.banExpiry) {
            user.banned = false
            user.banExpiry = 0
            return '*Ban Telah Berakhir*'
        }
        
        return `*${msToDate(user.banExpiry - now)}*`
    }

    conn.reply(m.chat, `
*Daftar Grup Dibanned*
• Total : ${chats.length} Chat${chats.length ? '\n' + chats.map(([jid], i) => `
• ${i + 1}. ${conn.getName(jid) === undefined ? 'Unknown' : conn.getName(jid)}
• ${jid}
`.trim()).join('\n') : ''}

*Daftar User Dibanned*
• Total : ${users.length} User${users.length ? '\n' + users.map(([jid], i) => {
    let user = global.db.data.users[jid]
    let banStatus = getBanStatus(user)
    return `
• ${i + 1}. ${conn.getName(jid) === undefined ? 'Unknown' : conn.getName(jid)}
• https://wa.me/${jid.split('@')[0]}
• Durasi: ${banStatus}
`.trim()}).join('\n') : ''}
`, m)
}

handler.help = ['listbanned']
handler.tags = ['info']
handler.command = /^listban(ned)?|ban(ned)?list|daftarban(ned)?$/i
module.exports = handler

function msToDate(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    let minutesms = ms % (60 * 1000);
    let sec = Math.floor((minutesms) / 1000);
    return `${days} Hari ${hours} Jam ${minutes} Menit ${sec} Detik`;
}