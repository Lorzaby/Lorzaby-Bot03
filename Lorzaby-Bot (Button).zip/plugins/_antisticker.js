let handler = m => m

handler.before = async function (m, { isAdmin, isBotAdmin, conn }) {
  if (m.isBaileys && m.fromMe) return true
  let chat = global.db.data.chats[m.chat]

  // Memeriksa apakah pesan adalah stiker
  let isSticker = m.mtype === 'stickerMessage'
  
  if (chat.antiSticker && isSticker) {
    if (!isAdmin && isBotAdmin) { // Jika pengirim bukan admin dan bot adalah admin
      await conn.sendMessage(m.chat, { delete: m.key }) // Langsung hapus stiker
    }
  }
  return true
}

module.exports = handler