const axios = require('axios');
const qs = require('qs');
const cheerio = require('cheerio');

async function instadl(url) {
    let data = qs.stringify({
        'url': url,
        'v': '3',
        'lang': 'en'
    });

    let config = {
        method: 'POST',
        url: 'https://api.downloadgram.org/media',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
            'Content-Type': 'application/x-www-form-urlencoded',
            'accept-language': 'id-ID',
            'referer': 'https://downloadgram.org/',
            'origin': 'https://downloadgram.org',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'priority': 'u=0',
            'te': 'trailers'
        },
        data: data
    };

    try {
        const response = await axios.request(config);
        const $ = cheerio.load(response.data);
        let mediaInfo = {};

        if ($('video').length) {
            mediaInfo.videoUrl = $('video source').attr('src');
            mediaInfo.downloadUrl = $('a[download]').attr('href');
            mediaInfo.posterUrl = $('video').attr('poster');
        } else if ($('img').length) {
            mediaInfo.imageUrl = $('img').attr('src');
            mediaInfo.downloadUrl = $('a[download]').attr('href');
        }
        
        for (let key in mediaInfo) {
            if (mediaInfo.hasOwnProperty(key)) {
                mediaInfo[key] = mediaInfo[key].replace(/\\\\"/g, '').replace(/\\"/g, '');
            }
        }

        return mediaInfo;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) {
        throw `*Cara penggunaan*\n\n${usedPrefix + command} URL_instagram\n\n*Contoh:*\n${usedPrefix + command} https://www.instagram.com/reel/ABC123/`;
    }

    if (!args[0].match(/https?:\/\/(www\.)?instagram\.com\/(p|reel|tv|stories)/i)) {
        throw '*Error:* URL tidak valid! Atau mungkin anda menggunakan versi Instagram terbaru karena saat ini bot belum mendukung URL dari versi Instagram yang baru.';
    }

    m.reply('📩 Loading...');
    
    try {
        const result = await instadl(args[0]);
        
        if (!result) {
            throw '*Error:* Gagal mengunduh media';
        }

        // Handle video
        if (result.videoUrl) {
            await conn.sendFile(
                m.chat,
                result.videoUrl,
                'instagram.mp4',
                `Done!\n- *Support:* https://bento.me/lorzaby`,
                m
            );
        }
        // Handle image
        else if (result.imageUrl) {
            await conn.sendFile(
                m.chat,
                result.imageUrl,
                'instagram.jpg',
                `Done!\n- *Support:* https://bento.me/lorzaby`,
                m
            );
        }
        else {
            throw '*Error:* Tidak ada media yang ditemukan';
        }
    } catch (e) {
        console.error('Error:', e);
        throw `*Error:* Terjadi kesalahan saat mengunduh.\n\n${e.message}`;
    }
};

handler.help = ['ig2'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(ig2)$/i;

handler.limit = true;
handler.group = false;
handler.premium = false;

module.exports = handler;