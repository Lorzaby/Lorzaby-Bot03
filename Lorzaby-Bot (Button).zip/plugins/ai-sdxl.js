const axios = require("axios");

let handler = async(m, { conn, text, usedPrefix, command }) => {
	if (!text) return m.reply(`Masukkan prompt!`);
	m.reply(wait);
	let res = await sdxlAnime(text);
	const { image } = res;
	await conn.sendFile(m.chat, image, "", "> Prompt: " + text, m);
}

handler.help = ["sdxl"];
handler.tags = ["ai"];
handler.command = /^(sdxl)$/i;
handler.limit = true;

module.exports = handler;

async function sdxlAnime(prompt) {
  try {
    return await new Promise(async(resolve, reject) => {
      if(!prompt) return reject("failed reading undefined prompt!");
      axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
        prompt,
        key: "Soft-Anime",
        width: 512,
        height: 768,
        quantity: 1,
        size: "512x768"
      }).then(res => {
        const data = res.data;
        if(data.code !== 0) return reject(data.message);
        if(data.data.safetyState === "RISKY") return reject("nsfw image was generated, you try create other image again!")
        if(!data.data?.url) return reject("failed generating image!")
        return resolve({
          status: true,
          image: data.data.url
        })
      }).catch(reject)
    })
  } catch (e) {
    return {
      status: false,
      message: e
    }
  }
}