let handler = async (m, { conn, isROwner, text }) => {
  let { spawn } = require('child_process');
  if (!process.send) throw '*Dont:* node main.js\n*Do: node index.js';
  
  if (global.conn.user.jid == conn.user.jid) {
    await m.reply('Sedang Merestart Bot...\n- Mohon tunggu sekitar 1 menit');
    process.send('reset');
    let phoneNumber = nomorown + "@s.whatsapp.net";
    let message = "Bot telah berhasil direstart!";
    await conn.sendMessage(phoneNumber, message, MessageType.text);
  } else throw 'eeeeeiiittsssss...';
}

module.exports = handler;